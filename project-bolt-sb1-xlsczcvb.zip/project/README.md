# Home Accounting

A comprehensive personal finance management application with AI-powered reporting capabilities. Built with React, TypeScript, Supabase, and Tailwind CSS.

**Fully bilingual**: Available in English and Russian with real-time language switching.

## Features

### Core Functionality

- **Account Management**: Manage multiple financial accounts (cards, bank accounts, deposits, cash)
- **Transaction Tracking**: Record income and expenses with detailed categorization
- **Categories & Subcategories**: Organize transactions with hierarchical categories
- **File Attachments**: Attach receipts, invoices, and documents to transactions before creation with drag-and-drop interface, seamless upload/download, and multi-file support
- **Account Transfers**: Transfer money between accounts with fee support
- **Monthly Budgets**: Set and track budgets for categories and subcategories with real-time spending updates and automatic hierarchy tracking
- **Income Tracking (Поступления)**: Plan and track expected income by category with real-time progress updates and subcategory support
- **Planned Transactions**: Schedule future income and expenses
- **AI-Powered Reports**: Generate dynamic charts and insights using natural language queries

### Technical Features

- **Multilingual Support**: Full internationalization with English and Russian languages
- **Progressive Web App (PWA)**: Install and use offline
- **Authentication**: Secure email/password authentication via Supabase
- **Real-time Database**: Powered by Supabase PostgreSQL
- **Responsive Design**: Optimized for all devices including iPhone 14 Plus/Pro Max, tablets, and desktop with adaptive layouts
- **Row Level Security**: Data isolation and security at database level
- **Modern UI**: Apple-inspired liquid glass design with smooth animations
- **Optimized Mobile Experience**: Compact forms, clear guidance, and touch-friendly interface for iOS and Android devices

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **Build Tool**: Vite
- **Icons**: Lucide React
- **Deployment**: Can be deployed to any static hosting

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Supabase account and project

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/home-accounting.git
cd home-accounting
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

4. Start the development server:
```bash
npm run dev
```

5. Build for production:
```bash
npm run build
```

## Database Schema

The application uses the following main tables:

- **accounts**: Financial accounts with balance tracking
- **categories**: Income/expense categories with hierarchical support
- **transactions**: All financial transactions
- **budgets**: Monthly budget allocations
- **planned_transactions**: Future scheduled transactions
- **attachments**: File storage metadata

All tables have Row Level Security (RLS) enabled for data isolation.

## Usage Guide

### Getting Started

1. **Sign Up**: Create an account using email and password
2. **Choose Language**: Switch between English and Russian using the language selector in the header
3. **Add Accounts**: Create your financial accounts (cards, banks, etc.)
4. **Create Categories**: Set up expense and income categories
5. **Record Transactions**: Add your income and expenses
6. **Set Budgets**: Define monthly spending limits
7. **Generate Reports**: Use AI queries to analyze your finances

### Language Support

The application supports both English and Russian languages with seamless switching:

- Click the language icon in the header to switch languages
- All interface elements update instantly
- Your language preference is saved automatically
- Dates and numbers are formatted according to the selected locale

### AI Reports

The AI Reports feature allows you to ask questions in natural language:

**English examples:**
- "show expenses by category"
- "monthly taxi expenses"
- "income vs expenses"
- "spending trends for groceries"

**Russian examples:**
- "покажи расходы по категориям"
- "ежемесячные расходы на такси"
- "доходы и расходы"

The system will generate appropriate visualizations (bar charts, pie charts) based on your query.

## Development

### Project Structure

```
src/
├── components/          # React components
│   ├── Auth.tsx        # Authentication
│   ├── Layout.tsx      # Main layout with navigation
│   ├── Dashboard.tsx   # Overview dashboard
│   ├── Accounts.tsx    # Account management
│   ├── Transactions.tsx # Transaction management
│   ├── TransactionFiles.tsx # File attachment handler
│   ├── PlannedAndBudgets.tsx # Planning features
│   └── Reports.tsx     # AI-powered reports
├── contexts/           # React contexts
│   ├── AuthContext.tsx # Authentication context
│   └── LanguageContext.tsx # Internationalization context
├── i18n/              # Internationalization
│   └── translations.ts # Translation strings (EN/RU)
├── lib/               # Utilities and configs
│   └── supabase.ts    # Supabase client and types
├── App.tsx            # Main app component
└── main.tsx           # Entry point
```

### Key Technologies

- **Vite**: Fast build tool and dev server
- **React**: UI library with hooks
- **TypeScript**: Type-safe JavaScript
- **Tailwind CSS**: Utility-first CSS framework
- **Supabase**: Backend-as-a-Service
  - PostgreSQL database
  - Authentication
  - Row Level Security
  - Real-time subscriptions

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Development Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Roadmap

See [CHANGELOG.md](CHANGELOG.md) for version history and upcoming features.

### Completed Features ✅

- [x] Full internationalization (English/Russian) with complete localization coverage
- [x] Progressive Web App (PWA) support
- [x] AI-powered reports with natural language queries
- [x] File attachments with seamless transaction form integration
- [x] Apple-inspired liquid glass UI design with smooth animations
- [x] Intuitive transfer icons with bidirectional arrows
- [x] Multi-account management with color coding
- [x] iPhone 14 Plus/Pro Max PWA optimization with responsive layout fixes
- [x] Compact transaction forms with improved mobile UX
- [x] Clear file attachment guidance and workflow
- [x] Real-time budget tracking with dynamic expense calculation
- [x] Mobile-optimized modal forms with proper scrolling
- [x] Budget support for subcategories with automatic hierarchy tracking
- [x] Pre-upload file attachments with drag-and-drop interface
- [x] Income tracking (Поступления) with expected income planning and progress monitoring

### Planned Features

- [ ] Multi-currency support with exchange rates
- [ ] Recurring transactions automation
- [ ] Export data to CSV/Excel
- [ ] Advanced filtering and search
- [ ] Custom report templates
- [ ] Additional languages (Spanish, French, German)
- [ ] Mobile native apps (React Native)
- [ ] Shared accounts for families
- [ ] Bank account integration via APIs
- [ ] Receipt OCR for automatic data entry
- [ ] Financial goal tracking
- [ ] Dark mode theme

## Security

- All user data is protected by Supabase Row Level Security
- Authentication uses industry-standard JWT tokens
- Database queries are parameterized to prevent SQL injection
- Client-side data is validated before submission
- HTTPS required for all API communications

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Contact: your-email@example.com

## Acknowledgments

- Built with [Supabase](https://supabase.com)
- Icons by [Lucide](https://lucide.dev)
- UI inspiration from modern finance apps
