# Contributing to Home Accounting

Thank you for considering contributing to Home Accounting! This document provides guidelines and instructions for contributing.

## Code of Conduct

By participating in this project, you agree to maintain a respectful and collaborative environment.

## How to Contribute

### Reporting Bugs

Before creating bug reports, please check existing issues. When creating a bug report, include:

- Clear and descriptive title
- Steps to reproduce the issue
- Expected behavior
- Actual behavior
- Screenshots if applicable
- Browser and OS information
- Any relevant error messages

### Suggesting Enhancements

Enhancement suggestions are welcome! Please provide:

- Clear description of the enhancement
- Use cases and benefits
- Possible implementation approach
- Any relevant examples from other apps

### Pull Requests

1. **Fork the repository** and create your branch from `main`
2. **Install dependencies**: `npm install`
3. **Make your changes** following the coding standards below
4. **Test your changes** thoroughly
5. **Update documentation** if needed
6. **Commit with clear messages** following the commit conventions
7. **Push to your fork** and submit a pull request

## Development Setup

### Prerequisites
- Node.js 18 or higher
- npm or yarn
- Supabase account (for backend features)

### Local Setup

```bash
git clone https://github.com/yourusername/home-accounting.git
cd home-accounting
npm install
cp .env.example .env
```

Edit `.env` with your Supabase credentials:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

Start development server:
```bash
npm run dev
```

### Project Structure

```
src/
├── components/      # React components
├── contexts/        # React contexts
├── lib/            # Utilities and configurations
├── App.tsx         # Main application
└── main.tsx        # Entry point
```

## Coding Standards

### TypeScript

- Use TypeScript for all new code
- Define proper types and interfaces
- Avoid `any` types when possible
- Use strict mode

### React

- Use functional components with hooks
- Follow React best practices
- Keep components focused and small
- Use meaningful component names

### Styling

- Use Tailwind CSS classes
- Follow mobile-first approach
- Maintain consistent spacing (multiples of 4px)
- Use theme colors from Tailwind config

### Code Style

- Run ESLint before committing: `npm run lint`
- Use 2 spaces for indentation
- Use single quotes for strings
- Add semicolons at end of statements
- Keep lines under 100 characters when reasonable

## Commit Messages

Follow the conventional commits format:

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

Examples:
```
feat(transactions): add file attachment support
fix(budgets): correct calculation for monthly budgets
docs(readme): update installation instructions
```

## Testing

Currently, the project uses manual testing. Contributions to add automated tests are welcome!

When testing:
- Test on multiple browsers (Chrome, Firefox, Safari)
- Test responsive design on different screen sizes
- Test with different data scenarios
- Check for console errors

## Database Changes

If your contribution involves database schema changes:

1. Document the changes in migration format
2. Update type definitions in `src/lib/supabase.ts`
3. Ensure RLS policies are properly configured
4. Test with multiple users to verify data isolation

## Documentation

- Update README.md for new features
- Add entries to CHANGELOG.md
- Include JSDoc comments for complex functions
- Update type definitions

## Review Process

1. All PRs require review before merging
2. Address review comments promptly
3. Keep PRs focused on a single feature/fix
4. Ensure CI checks pass

## Feature Requests

For large features:

1. Open an issue first to discuss
2. Wait for maintainer feedback
3. Break into smaller PRs if needed
4. Update roadmap in CHANGELOG.md

## Questions?

Feel free to:
- Open an issue for questions
- Join discussions in existing issues
- Reach out to maintainers

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

## Recognition

Contributors will be recognized in the project README and release notes.

Thank you for contributing!
