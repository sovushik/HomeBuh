import { useEffect, useState } from 'react';
import { supabase, Account, Category, PlannedTransaction, Budget, IncomeBudget } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Plus, Calendar, Target, Check, X, TrendingUp, TrendingDown } from 'lucide-react';

export const PlannedAndBudgets = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [planned, setPlanned] = useState<PlannedTransaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [incomeBudgets, setIncomeBudgets] = useState<IncomeBudget[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'planned' | 'budgets' | 'income'>('planned');
  const [showPlannedModal, setShowPlannedModal] = useState(false);
  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [showIncomeBudgetModal, setShowIncomeBudgetModal] = useState(false);

  const [plannedForm, setPlannedForm] = useState({
    type: 'expense' as 'income' | 'expense',
    amount: '',
    account_id: '',
    category_id: '',
    description: '',
    planned_date: '',
  });

  const [budgetForm, setBudgetForm] = useState({
    category_id: '',
    amount: '',
    month: new Date().toISOString().slice(0, 7),
  });

  const [incomeBudgetForm, setIncomeBudgetForm] = useState({
    category_id: '',
    amount: '',
    month: new Date().toISOString().slice(0, 7),
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);

    const [accountsRes, categoriesRes, plannedRes, budgetsRes, incomeBudgetsRes, transactionsRes] = await Promise.all([
      supabase.from('accounts').select('*').order('name'),
      supabase.from('categories').select('*').order('name'),
      supabase
        .from('planned_transactions')
        .select('*')
        .order('planned_date', { ascending: true }),
      supabase.from('budgets').select('*').order('period_start', { ascending: false }),
      supabase.from('income_budgets').select('*').order('period_start', { ascending: false }),
      supabase.from('transactions').select('*'),
    ]);

    setAccounts(accountsRes.data || []);
    setCategories(categoriesRes.data || []);
    setPlanned(plannedRes.data || []);
    setBudgets(budgetsRes.data || []);
    setIncomeBudgets(incomeBudgetsRes.data || []);
    setTransactions(transactionsRes.data || []);
    setLoading(false);
  };

  const handleCreatePlanned = async (e: React.FormEvent) => {
    e.preventDefault();

    await supabase.from('planned_transactions').insert({
      user_id: user!.id,
      type: plannedForm.type,
      amount: Number(plannedForm.amount),
      account_id: plannedForm.account_id,
      category_id: plannedForm.category_id || null,
      description: plannedForm.description,
      planned_date: plannedForm.planned_date,
      is_completed: false,
    });

    setPlannedForm({
      type: 'expense',
      amount: '',
      account_id: '',
      category_id: '',
      description: '',
      planned_date: '',
    });
    setShowPlannedModal(false);
    loadData();
  };

  const handleCompletePlanned = async (planned: PlannedTransaction) => {
    const account = accounts.find((a) => a.id === planned.account_id);
    if (!account) return;

    const { data: transaction } = await supabase
      .from('transactions')
      .insert({
        user_id: user!.id,
        type: planned.type,
        amount: planned.amount,
        account_id: planned.account_id,
        category_id: planned.category_id,
        description: planned.description,
        date: new Date().toISOString().split('T')[0],
      })
      .select()
      .single();

    if (transaction) {
      const newBalance =
        planned.type === 'income'
          ? Number(account.balance) + Number(planned.amount)
          : Number(account.balance) - Number(planned.amount);

      await supabase
        .from('accounts')
        .update({ balance: newBalance, updated_at: new Date().toISOString() })
        .eq('id', account.id);

      await supabase
        .from('planned_transactions')
        .update({ is_completed: true, completed_transaction_id: transaction.id })
        .eq('id', planned.id);

      loadData();
    }
  };

  const handleDeletePlanned = async (id: string) => {
    if (confirm(t.planned.deletePlannedConfirm)) {
      await supabase.from('planned_transactions').delete().eq('id', id);
      loadData();
    }
  };

  const handleCreateBudget = async (e: React.FormEvent) => {
    e.preventDefault();

    const [year, month] = budgetForm.month.split('-');
    const periodStart = `${year}-${month}-01`;
    const periodEnd = new Date(Number(year), Number(month), 0).toISOString().split('T')[0];

    await supabase.from('budgets').insert({
      user_id: user!.id,
      category_id: budgetForm.category_id,
      amount: Number(budgetForm.amount),
      period_start: periodStart,
      period_end: periodEnd,
    });

    setBudgetForm({
      category_id: '',
      amount: '',
      month: new Date().toISOString().slice(0, 7),
    });
    setShowBudgetModal(false);
    loadData();
  };

  const handleCreateIncomeBudget = async (e: React.FormEvent) => {
    e.preventDefault();

    const [year, month] = incomeBudgetForm.month.split('-');
    const periodStart = `${year}-${month}-01`;
    const periodEnd = new Date(Number(year), Number(month), 0).toISOString().split('T')[0];

    await supabase.from('income_budgets').insert({
      user_id: user!.id,
      category_id: incomeBudgetForm.category_id,
      amount: Number(incomeBudgetForm.amount),
      period_start: periodStart,
      period_end: periodEnd,
    });

    setIncomeBudgetForm({
      category_id: '',
      amount: '',
      month: new Date().toISOString().slice(0, 7),
    });
    setShowIncomeBudgetModal(false);
    loadData();
  };

  const getBudgetProgress = (budget: Budget) => {
    const budgetCategory = categories.find((c) => c.id === budget.category_id);
    if (!budgetCategory) return { spent: 0, percentage: 0 };

    const subcategories = categories.filter((c) => c.parent_id === budget.category_id);
    const categoryIds = budgetCategory.parent_id
      ? [budget.category_id]
      : [budget.category_id, ...subcategories.map((c) => c.id)];

    const monthTransactions = transactions.filter(
      (t) =>
        categoryIds.includes(t.category_id) &&
        t.date >= budget.period_start &&
        t.date <= budget.period_end &&
        t.type === 'expense'
    );

    const spent = monthTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
    const percentage = (spent / Number(budget.amount)) * 100;
    return { spent, percentage: Math.min(percentage, 100) };
  };

  const getIncomeBudgetProgress = (incomeBudget: IncomeBudget) => {
    const budgetCategory = categories.find((c) => c.id === incomeBudget.category_id);
    if (!budgetCategory) return { received: 0, percentage: 0 };

    const subcategories = categories.filter((c) => c.parent_id === incomeBudget.category_id);
    const categoryIds = budgetCategory.parent_id
      ? [incomeBudget.category_id]
      : [incomeBudget.category_id, ...subcategories.map((c) => c.id)];

    const monthTransactions = transactions.filter(
      (t) =>
        categoryIds.includes(t.category_id) &&
        t.date >= incomeBudget.period_start &&
        t.date <= incomeBudget.period_end &&
        t.type === 'income'
    );

    const received = monthTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
    const percentage = (received / Number(incomeBudget.amount)) * 100;
    return { received, percentage: Math.min(percentage, 100) };
  };

  const [transactions, setTransactions] = useState<any[]>([]);

  const mainCategories = categories.filter((c) => !c.parent_id);
  const expenseCategories = categories.filter((c) => c.type === 'expense');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-slate-800">{t.planned.title}</h1>
      </div>

      <div className="mb-6 flex gap-2">
        <button
          onClick={() => setActiveTab('planned')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
            activeTab === 'planned'
              ? 'bg-emerald-500 text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          <Calendar className="w-5 h-5" />
          {t.planned.plannedTransactions}
        </button>
        <button
          onClick={() => setActiveTab('budgets')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
            activeTab === 'budgets'
              ? 'bg-emerald-500 text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          <Target className="w-5 h-5" />
          {t.planned.budgets}
        </button>
        <button
          onClick={() => setActiveTab('income')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
            activeTab === 'income'
              ? 'bg-emerald-500 text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          <TrendingUp className="w-5 h-5" />
          {t.planned.incomeBudgets}
        </button>
      </div>

      {activeTab === 'income' ? (
        <div>
          <div className="flex justify-end mb-4">
            <button
              onClick={() => setShowIncomeBudgetModal(true)}
              className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition"
            >
              <Plus className="w-5 h-5" />
              {t.planned.newIncomeBudget}
            </button>
          </div>

          <div className="space-y-4">
            {incomeBudgets.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center text-slate-500">
                {t.planned.noIncomeBudgets}
              </div>
            ) : (
              incomeBudgets.map((incomeBudget) => {
                const category = categories.find((c) => c.id === incomeBudget.category_id);
                const { received, percentage } = getIncomeBudgetProgress(incomeBudget);
                return (
                  <div
                    key={incomeBudget.id}
                    className="bg-white rounded-xl shadow-sm border border-slate-200 p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-slate-800">{category?.name}</h3>
                        <p className="text-sm text-slate-500">
                          {new Date(incomeBudget.period_start).toLocaleDateString('ru-RU', {
                            month: 'long',
                            year: 'numeric',
                          })}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-emerald-600">
                          {received.toLocaleString('ru-RU', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}{' '}
                          ₽
                        </div>
                        <div className="text-sm text-slate-500">
                          {t.planned.of}{' '}
                          {Number(incomeBudget.amount).toLocaleString('ru-RU', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}{' '}
                          ₽
                        </div>
                      </div>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                      <div
                        className="h-full transition-all rounded-full bg-emerald-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <div className="mt-2 text-sm text-right text-slate-600">
                      {percentage.toFixed(0)}% {t.planned.received}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : activeTab === 'planned' ? (
        <div>
          <div className="flex justify-end mb-4">
            <button
              onClick={() => setShowPlannedModal(true)}
              className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition"
            >
              <Plus className="w-5 h-5" />
              {t.planned.newPlanned}
            </button>
          </div>

          <div className="space-y-4">
            {planned.filter((p) => !p.is_completed).length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center text-slate-500">
                {t.planned.noPlanned}
              </div>
            ) : (
              planned
                .filter((p) => !p.is_completed)
                .map((p) => {
                  const account = accounts.find((a) => a.id === p.account_id);
                  const category = categories.find((c) => c.id === p.category_id);
                  return (
                    <div
                      key={p.id}
                      className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div
                          className={`p-2 rounded-lg ${
                            p.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                          }`}
                        >
                          {p.type === 'income' ? (
                            <TrendingUp className="w-5 h-5 text-green-600" />
                          ) : (
                            <TrendingDown className="w-5 h-5 text-red-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="font-medium text-slate-800">
                            {p.description || t.noDescription}
                          </div>
                          <div className="text-sm text-slate-500 flex items-center gap-2">
                            <span>{new Date(p.planned_date).toLocaleDateString('ru-RU')}</span>
                            <span>•</span>
                            <span>{account?.name}</span>
                            {category && (
                              <>
                                <span>•</span>
                                <span>{category.name}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div
                          className={`text-lg font-semibold ${
                            p.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}
                        >
                          {p.type === 'income' ? '+' : '-'}
                          {Number(p.amount).toLocaleString('ru-RU', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })} ₽
                        </div>
                        <button
                          onClick={() => handleCompletePlanned(p)}
                          className="p-2 bg-green-50 hover:bg-green-100 text-green-600 rounded-lg transition"
                          title={t.planned.complete}
                        >
                          <Check className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleDeletePlanned(p.id)}
                          className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition"
                          title={t.delete}
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>
      ) : (
        <div>
          <div className="flex justify-end mb-4">
            <button
              onClick={() => setShowBudgetModal(true)}
              className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition"
            >
              <Plus className="w-5 h-5" />
              {t.planned.newBudget}
            </button>
          </div>

          <div className="space-y-4">
            {budgets.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center text-slate-500">
                {t.planned.noBudgets}
              </div>
            ) : (
              budgets.map((budget) => {
                const category = categories.find((c) => c.id === budget.category_id);
                const { spent, percentage } = getBudgetProgress(budget);
                return (
                  <div
                    key={budget.id}
                    className="bg-white rounded-xl shadow-sm border border-slate-200 p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-slate-800">{category?.name}</h3>
                        <p className="text-sm text-slate-500">
                          {new Date(budget.period_start).toLocaleDateString('ru-RU', {
                            month: 'long',
                            year: 'numeric',
                          })}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-slate-800">
                          {spent.toLocaleString('ru-RU', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}{' '}
                          ₽
                        </div>
                        <div className="text-sm text-slate-500">
                          {t.planned.of}{' '}
                          {Number(budget.amount).toLocaleString('ru-RU', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0,
                          })}{' '}
                          ₽
                        </div>
                      </div>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full transition-all rounded-full ${
                          percentage >= 100
                            ? 'bg-red-500'
                            : percentage >= 80
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <div className="mt-2 text-sm text-right text-slate-600">
                      {percentage.toFixed(0)}% {t.planned.used}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {showPlannedModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">{t.planned.newPlanned}</h2>

            <form onSubmit={handleCreatePlanned} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.type}</label>
                <select
                  value={plannedForm.type}
                  onChange={(e) =>
                    setPlannedForm({ ...plannedForm, type: e.target.value as 'income' | 'expense' })
                  }
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="expense">{t.transactions.types.expense}</option>
                  <option value="income">{t.transactions.types.income}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.amount}</label>
                <input
                  type="number"
                  step="0.01"
                  value={plannedForm.amount}
                  onChange={(e) => setPlannedForm({ ...plannedForm, amount: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.account}</label>
                <select
                  value={plannedForm.account_id}
                  onChange={(e) => setPlannedForm({ ...plannedForm, account_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                >
                  <option value="">{t.transactions.selectAccount}</option>
                  {accounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.category}</label>
                <select
                  value={plannedForm.category_id}
                  onChange={(e) => setPlannedForm({ ...plannedForm, category_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="">{t.transactions.noCategory}</option>
                  {mainCategories
                    .filter((c) => c.type === plannedForm.type)
                    .map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  {t.transactions.description}
                </label>
                <input
                  type="text"
                  value={plannedForm.description}
                  onChange={(e) => setPlannedForm({ ...plannedForm, description: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  placeholder={t.transactions.descriptionPlaceholder}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  {t.planned.plannedDate}
                </label>
                <input
                  type="date"
                  value={plannedForm.planned_date}
                  onChange={(e) => setPlannedForm({ ...plannedForm, planned_date: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowPlannedModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition"
                >
                  {t.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showBudgetModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">{t.planned.newBudget}</h2>

            <form onSubmit={handleCreateBudget} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.category}</label>
                <select
                  value={budgetForm.category_id}
                  onChange={(e) => setBudgetForm({ ...budgetForm, category_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                >
                  <option value="">{t.transactions.selectCategory}</option>
                  {expenseCategories.map((category) => {
                    const isSubcategory = category.parent_id;
                    const parentCategory = isSubcategory
                      ? categories.find((c) => c.id === category.parent_id)
                      : null;
                    return (
                      <option key={category.id} value={category.id}>
                        {isSubcategory && parentCategory ? `${parentCategory.name} → ${category.name}` : category.name}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.amount}</label>
                <input
                  type="number"
                  step="0.01"
                  value={budgetForm.amount}
                  onChange={(e) => setBudgetForm({ ...budgetForm, amount: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.planned.month}</label>
                <input
                  type="month"
                  value={budgetForm.month}
                  onChange={(e) => setBudgetForm({ ...budgetForm, month: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowBudgetModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition"
                >
                  {t.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {showIncomeBudgetModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">{t.planned.newIncomeBudget}</h2>

            <form onSubmit={handleCreateIncomeBudget} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.category}</label>
                <select
                  value={incomeBudgetForm.category_id}
                  onChange={(e) => setIncomeBudgetForm({ ...incomeBudgetForm, category_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                >
                  <option value="">{t.transactions.selectCategory}</option>
                  {categories.filter((c) => c.type === 'income').map((category) => {
                    const isSubcategory = category.parent_id;
                    const parentCategory = isSubcategory
                      ? categories.find((c) => c.id === category.parent_id)
                      : null;
                    return (
                      <option key={category.id} value={category.id}>
                        {isSubcategory && parentCategory ? `${parentCategory.name} → ${category.name}` : category.name}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.amount}</label>
                <input
                  type="number"
                  step="0.01"
                  value={incomeBudgetForm.amount}
                  onChange={(e) => setIncomeBudgetForm({ ...incomeBudgetForm, amount: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.planned.month}</label>
                <input
                  type="month"
                  value={incomeBudgetForm.month}
                  onChange={(e) => setIncomeBudgetForm({ ...incomeBudgetForm, month: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowIncomeBudgetModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition"
                >
                  {t.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
