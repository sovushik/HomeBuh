import { useState, useEffect } from 'react';
import { supabase, TransactionFile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Paperclip, Download, Trash2, Upload, FileText } from 'lucide-react';

type TransactionFilesProps = {
  transactionId: string | null;
};

export const TransactionFiles = ({ transactionId }: TransactionFilesProps) => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [files, setFiles] = useState<TransactionFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (transactionId) {
      loadFiles();
    } else {
      setFiles([]);
      setLoading(false);
    }
  }, [transactionId]);

  const loadFiles = async () => {
    if (!transactionId) return;

    setLoading(true);
    const { data } = await supabase
      .from('transaction_files')
      .select('*')
      .eq('transaction_id', transactionId)
      .order('created_at', { ascending: false });

    setFiles(data || []);
    setLoading(false);
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || !event.target.files[0] || !transactionId || !user) return;

    const file = event.target.files[0];
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}.${fileExt}`;
    const filePath = `${user.id}/${fileName}`;

    setUploading(true);

    try {
      const { error: uploadError } = await supabase.storage
        .from('transaction-files')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase.from('transaction_files').insert({
        transaction_id: transactionId,
        file_name: file.name,
        file_path: filePath,
        file_size: file.size,
        file_type: file.type,
        uploaded_by: user.id,
      });

      if (dbError) throw dbError;

      await loadFiles();
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const handleDownload = async (file: TransactionFile) => {
    try {
      const { data, error } = await supabase.storage
        .from('transaction-files')
        .download(file.file_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.file_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading file:', error);
      alert('Error downloading file');
    }
  };

  const handleDelete = async (file: TransactionFile) => {
    if (!confirm(t.transactions.deleteFile + '?')) return;

    try {
      await supabase.storage.from('transaction-files').remove([file.file_path]);
      await supabase.from('transaction_files').delete().eq('id', file.id);
      await loadFiles();
    } catch (error) {
      console.error('Error deleting file:', error);
      alert('Error deleting file');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  if (!transactionId) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <Paperclip className="w-4 h-4" />
            {t.transactions.attachments}
          </h3>
        </div>
        <div className="text-sm text-slate-500 text-center py-4 glass rounded-xl border border-slate-200">
          {t.transactions.saveToAttach || 'Сохраните транзакцию, чтобы прикрепить файлы'}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-800 flex items-center gap-2">
          <Paperclip className="w-4 h-4" />
          {t.transactions.attachments}
        </h3>
        <label className="flex items-center gap-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition cursor-pointer text-sm font-medium">
          <Upload className="w-4 h-4" />
          {t.transactions.uploadFile}
          <input
            type="file"
            onChange={handleFileUpload}
            disabled={uploading}
            className="hidden"
          />
        </label>
      </div>

      {loading ? (
        <div className="text-center py-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
        </div>
      ) : files.length === 0 ? (
        <div className="text-sm text-slate-500 text-center py-4 glass rounded-xl">
          {t.transactions.noFiles}
        </div>
      ) : (
        <div className="space-y-2">
          {files.map((file) => (
            <div
              key={file.id}
              className="glass-card p-3 rounded-xl flex items-center justify-between hover:bg-white/60 transition"
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-slate-800 truncate">
                    {file.file_name}
                  </div>
                  <div className="text-xs text-slate-500">
                    {formatFileSize(file.file_size)}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownload(file)}
                  className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition"
                  title={t.transactions.downloadFile}
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(file)}
                  className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition"
                  title={t.transactions.deleteFile}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {uploading && (
        <div className="text-sm text-blue-600 text-center py-2">
          {t.loading}
        </div>
      )}
    </div>
  );
};
