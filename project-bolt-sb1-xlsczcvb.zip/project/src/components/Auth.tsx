import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Wallet } from 'lucide-react';

export const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const { t } = useLanguage();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const { error } = isLogin
      ? await signIn(email, password)
      : await signUp(email, password);

    if (error) {
      setError(error.message);
    } else if (!isLogin) {
      setError('Registration successful! Please sign in.');
      setIsLogin(true);
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-blue-400/30 to-transparent rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-sky-400/30 to-transparent rounded-full blur-3xl" style={{ animationDelay: '1.5s' }}></div>
      </div>

      <div className="glass-card rounded-3xl w-full max-w-md p-8 relative z-10 animate-float">
        <div className="flex items-center justify-center mb-8">
          <div className="gradient-blue p-4 rounded-2xl shadow-xl">
            <Wallet className="w-10 h-10 text-white" />
          </div>
        </div>

        <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent mb-2">
          {t.appName}
        </h1>
        <p className="text-center text-slate-600 mb-8 font-medium">
          {isLogin ? t.auth.signIn : t.auth.signUp}
        </p>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {t.auth.email}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl glass border-0 focus:ring-2 focus:ring-blue-400 outline-none transition placeholder:text-slate-400"
              placeholder="your@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {t.auth.password}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl glass border-0 focus:ring-2 focus:ring-blue-400 outline-none transition placeholder:text-slate-400"
              placeholder="••••••••"
              required
              minLength={6}
            />
          </div>

          {error && (
            <div className={`p-4 rounded-xl text-sm font-medium glass ${
              error.includes('successful')
                ? 'text-blue-700 border border-blue-200'
                : 'text-red-700 border border-red-200'
            }`}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full gradient-blue text-white font-semibold py-4 rounded-xl transition-all hover:shadow-xl hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            {loading ? t.loading : isLogin ? t.auth.signInButton : t.auth.signUpButton}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
            }}
            className="text-sm text-blue-600 hover:text-blue-700 font-semibold transition"
          >
            {isLogin ? t.auth.dontHaveAccount + ' ' + t.auth.signUp : t.auth.alreadyHaveAccount + ' ' + t.auth.signIn}
          </button>
        </div>
      </div>
    </div>
  );
};
