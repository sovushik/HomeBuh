import { ReactNode } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import {
  Wallet,
  TrendingUp,
  Calendar,
  PieChart,
  LayoutDashboard,
  LogOut,
  Menu,
  X,
  Languages,
  Info
} from 'lucide-react';
import { useState } from 'react';

type LayoutProps = {
  children: ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
};

export const Layout = ({ children, activeTab, onTabChange }: LayoutProps) => {
  const { signOut, user } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showChangelog, setShowChangelog] = useState(false);

  const version = '1.2.5';

  const navigation = [
    { id: 'dashboard', name: t.nav.dashboard, icon: LayoutDashboard },
    { id: 'accounts', name: t.nav.accounts, icon: Wallet },
    { id: 'transactions', name: t.nav.transactions, icon: TrendingUp },
    { id: 'planned', name: t.nav.planned, icon: Calendar },
    { id: 'reports', name: t.nav.reports, icon: PieChart },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-gradient-to-tr from-sky-400/20 to-transparent rounded-full blur-3xl"></div>
      </div>

      <nav className="glass sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-18 gap-2">
            <div className="flex items-center flex-shrink-0 min-w-0">
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className="gradient-blue p-2 sm:p-2.5 rounded-xl shadow-lg flex-shrink-0">
                  <Wallet className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <span className="text-base sm:text-xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent truncate">
                  {t.appName}
                </span>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all ${
                      activeTab === item.id
                        ? 'gradient-blue text-white shadow-lg'
                        : 'text-slate-700 hover:bg-white/50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-semibold">{item.name}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
              <div className="hidden lg:block text-sm font-medium text-slate-700 bg-white/50 px-4 py-2 rounded-xl max-w-[200px] truncate">
                {user?.email}
              </div>
              <button
                onClick={() => setLanguage(language === 'en' ? 'ru' : 'en')}
                className="flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-2 sm:py-2.5 text-slate-700 hover:bg-white/50 rounded-xl transition-all flex-shrink-0"
                title={language === 'en' ? 'Русский' : 'English'}
              >
                <Languages className="w-5 h-5" />
                <span className="font-semibold text-sm hidden sm:inline">{language.toUpperCase()}</span>
              </button>
              <button
                onClick={() => signOut()}
                className="flex items-center gap-2 px-2 sm:px-4 py-2 sm:py-2.5 text-slate-700 hover:text-red-600 hover:bg-white/50 rounded-xl transition-all flex-shrink-0"
              >
                <LogOut className="w-5 h-5" />
                <span className="hidden lg:inline font-semibold">{t.signOut}</span>
              </button>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-slate-700 hover:bg-white/50 rounded-xl flex-shrink-0"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden glass-card mt-2 mx-4 mb-4 rounded-2xl overflow-hidden">
            <div className="px-4 py-3 space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onTabChange(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all ${
                      activeTab === item.id
                        ? 'gradient-blue text-white shadow-lg'
                        : 'text-slate-700 hover:bg-white/50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-semibold">{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 relative z-10">
        {children}
      </main>

      <button
        onClick={() => setShowChangelog(true)}
        className="fixed bottom-4 right-4 flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-50 text-slate-600 rounded-full shadow-lg border border-slate-200 transition-all hover:shadow-xl z-50"
        title={t.version.viewChangelog}
      >
        <Info className="w-4 h-4" />
        <span className="text-sm font-medium">v{version}</span>
      </button>

      {showChangelog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{t.version.title}</h2>
                <p className="text-sm text-slate-500 mt-1">v{version}</p>
              </div>
              <button
                onClick={() => setShowChangelog(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-6 h-6 text-slate-600" />
              </button>
            </div>

            <div className="overflow-y-auto p-6 space-y-8">
              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.5 - 2025-12-07</h3>
                <h4 className="font-semibold text-emerald-600 mb-2">{t.version.incomeTracking}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes125.item1}</li>
                  <li>• {t.version.changes125.item2}</li>
                  <li>• {t.version.changes125.item3}</li>
                  <li>• {t.version.changes125.item4}</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.4 - 2025-12-07</h3>
                <h4 className="font-semibold text-blue-600 mb-2">{t.version.budgetSubcategories}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes124.item1}</li>
                  <li>• {t.version.changes124.item2}</li>
                  <li>• {t.version.changes124.item3}</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.3 - 2025-12-07</h3>
                <h4 className="font-semibold text-amber-600 mb-2">{t.version.bugFixes}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes123.item1}</li>
                  <li>• {t.version.changes123.item2}</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.2 - 2025-12-07</h3>
                <h4 className="font-semibold text-purple-600 mb-2">{t.version.fileAttachments}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes122.item1}</li>
                  <li>• {t.version.changes122.item2}</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.1 - 2025-12-07</h3>
                <h4 className="font-semibold text-teal-600 mb-2">{t.version.aiReports}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes121.item1}</li>
                  <li>• {t.version.changes121.item2}</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-800 mb-2">v1.2.0 - 2025-12-07</h3>
                <h4 className="font-semibold text-indigo-600 mb-2">{t.version.majorFeatures}</h4>
                <ul className="space-y-1 text-sm text-slate-700">
                  <li>• {t.version.changes120.item1}</li>
                  <li>• {t.version.changes120.item2}</li>
                  <li>• {t.version.changes120.item3}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
