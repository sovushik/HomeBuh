import { useEffect, useState } from 'react';
import { supabase, Account, Transaction } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { TrendingUp, TrendingDown, Wallet, AlertCircle, ArrowRightLeft } from 'lucide-react';

export const Dashboard = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalBalance: 0,
    monthIncome: 0,
    monthExpense: 0,
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: accountsData } = await supabase
        .from('accounts')
        .select('*')
        .order('created_at', { ascending: false });

      const { data: transactionsData } = await supabase
        .from('transactions')
        .select('*')
        .order('date', { ascending: false })
        .limit(5);

      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: monthTransactions } = await supabase
        .from('transactions')
        .select('*')
        .gte('date', startOfMonth.toISOString().split('T')[0]);

      setAccounts(accountsData || []);
      setRecentTransactions(transactionsData || []);

      const totalBalance = (accountsData || []).reduce(
        (sum, acc) => sum + Number(acc.balance),
        0
      );

      const monthIncome = (monthTransactions || [])
        .filter((t) => t.type === 'income')
        .reduce((sum, t) => sum + Number(t.amount), 0);

      const monthExpense = (monthTransactions || [])
        .filter((t) => t.type === 'expense')
        .reduce((sum, t) => sum + Number(t.amount), 0);

      setStats({ totalBalance, monthIncome, monthExpense });
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card glass-hover rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-500 to-sky-400 rounded-xl shadow-lg">
              <Wallet className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent">
            {stats.totalBalance.toLocaleString('ru-RU', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })} ₽
          </div>
          <div className="text-sm text-slate-600 mt-2 font-medium">{t.dashboard.totalBalance}</div>
        </div>

        <div className="glass-card glass-hover rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-400 rounded-xl shadow-lg">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="text-3xl font-bold text-green-600">
            +{stats.monthIncome.toLocaleString('ru-RU', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })} ₽
          </div>
          <div className="text-sm text-slate-600 mt-2 font-medium">{t.dashboard.incomeThisMonth}</div>
        </div>

        <div className="glass-card glass-hover rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-red-500 to-rose-400 rounded-xl shadow-lg">
              <TrendingDown className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="text-3xl font-bold text-red-600">
            -{stats.monthExpense.toLocaleString('ru-RU', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })} ₽
          </div>
          <div className="text-sm text-slate-600 mt-2 font-medium">{t.dashboard.expensesThisMonth}</div>
        </div>
      </div>

      {accounts.length === 0 ? (
        <div className="glass-card rounded-2xl p-6 border border-amber-200/50">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-400 rounded-xl">
              <AlertCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-1">
                {t.dashboard.noAccounts}
              </h3>
              <p className="text-slate-600 font-medium">
                {t.dashboard.noAccountsDescription}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="glass-card rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/30">
              <h2 className="text-2xl font-bold text-slate-800">{t.accounts.title}</h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {accounts.map((account) => (
                  <div
                    key={account.id}
                    className="glass-hover p-5 rounded-2xl border-2"
                    style={{ borderColor: account.color + '40' }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-bold text-slate-800">{account.name}</span>
                      <span className="text-xs glass px-3 py-1 rounded-full font-semibold text-slate-700">
                        {t.accounts.types[account.type as keyof typeof t.accounts.types]}
                      </span>
                    </div>
                    <div className="text-2xl font-bold text-slate-800">
                      {Number(account.balance).toLocaleString('ru-RU', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}{' '}
                      {account.currency}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {recentTransactions.length > 0 && (
            <div className="glass-card rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-white/30">
                <h2 className="text-2xl font-bold text-slate-800">{t.dashboard.recentTransactions}</h2>
              </div>
              <div className="divide-y divide-white/30">
                {recentTransactions.map((transaction) => (
                  <div key={transaction.id} className="p-6 flex items-center justify-between hover:bg-white/30 transition">
                    <div className="flex items-center gap-4">
                      <div
                        className={`p-3 rounded-xl shadow-lg ${
                          transaction.type === 'income'
                            ? 'bg-gradient-to-br from-green-500 to-emerald-400'
                            : transaction.type === 'expense'
                            ? 'bg-gradient-to-br from-red-500 to-rose-400'
                            : 'bg-gradient-to-br from-blue-500 to-sky-400'
                        }`}
                      >
                        {transaction.type === 'income' ? (
                          <TrendingUp className="w-5 h-5 text-white" />
                        ) : transaction.type === 'expense' ? (
                          <TrendingDown className="w-5 h-5 text-white" />
                        ) : (
                          <ArrowRightLeft className="w-5 h-5 text-white" />
                        )}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">
                          {transaction.description || 'No description'}
                        </div>
                        <div className="text-sm text-slate-600 font-medium">
                          {new Date(transaction.date).toLocaleDateString('ru-RU')}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`text-lg font-bold ${
                        transaction.type === 'income'
                          ? 'text-green-600'
                          : 'text-red-600'
                      }`}
                    >
                      {transaction.type === 'income' ? '+' : '-'}
                      {Number(transaction.amount).toLocaleString('ru-RU', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })} ₽
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
