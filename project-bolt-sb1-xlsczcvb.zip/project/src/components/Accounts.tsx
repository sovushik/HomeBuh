import { useEffect, useState } from 'react';
import { supabase, Account } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Plus, Trash2, Edit2, CreditCard, Building, PiggyBank, Wallet } from 'lucide-react';

const COLORS = [
  '#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899', '#06b6d4', '#84cc16'
];

export const Accounts = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'card' as Account['type'],
    balance: '0',
    currency: 'RUB',
    color: COLORS[0],
    icon: 'wallet',
  });

  const ACCOUNT_TYPES = [
    { value: 'card', label: t.accounts.types.card, icon: CreditCard },
    { value: 'bank', label: t.accounts.types.bank, icon: Building },
    { value: 'savings', label: t.accounts.types.savings, icon: PiggyBank },
    { value: 'cash', label: t.accounts.types.cash, icon: Wallet },
  ];

  useEffect(() => {
    if (user) {
      loadAccounts();
    }
  }, [user]);

  const loadAccounts = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('accounts')
      .select('*')
      .order('created_at', { ascending: false });

    setAccounts(data || []);
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingAccount) {
      await supabase
        .from('accounts')
        .update({
          name: formData.name,
          type: formData.type,
          balance: Number(formData.balance),
          currency: formData.currency,
          color: formData.color,
          icon: formData.icon,
          updated_at: new Date().toISOString(),
        })
        .eq('id', editingAccount.id);
    } else {
      await supabase.from('accounts').insert({
        user_id: user!.id,
        name: formData.name,
        type: formData.type,
        balance: Number(formData.balance),
        currency: formData.currency,
        color: formData.color,
        icon: formData.icon,
      });
    }

    resetForm();
    loadAccounts();
  };

  const handleDelete = async (id: string) => {
    if (confirm(t.accounts.deleteAccountConfirm)) {
      await supabase.from('accounts').delete().eq('id', id);
      loadAccounts();
    }
  };

  const handleEdit = (account: Account) => {
    setEditingAccount(account);
    setFormData({
      name: account.name,
      type: account.type,
      balance: account.balance.toString(),
      currency: account.currency,
      color: account.color,
      icon: account.icon,
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'card',
      balance: '0',
      currency: 'RUB',
      color: COLORS[0],
      icon: 'wallet',
    });
    setEditingAccount(null);
    setShowModal(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent">{t.accounts.title}</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 gradient-blue text-white px-6 py-3 rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all font-semibold"
        >
          <Plus className="w-5 h-5" />
          {t.accounts.addAccount}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts.map((account) => {
          const TypeIcon = ACCOUNT_TYPES.find((t) => t.value === account.type)?.icon || Wallet;
          return (
            <div
              key={account.id}
              className="glass-card glass-hover rounded-2xl border-2 p-6"
              style={{ borderColor: account.color }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className="p-3 rounded-lg"
                    style={{ backgroundColor: `${account.color}20` }}
                  >
                    <TypeIcon className="w-6 h-6" style={{ color: account.color }} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">{account.name}</h3>
                    <span className="text-xs text-slate-500">{t.accounts.types[account.type as keyof typeof t.accounts.types]}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(account)}
                    className="p-2 text-slate-400 hover:text-emerald-600 transition"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(account.id)}
                    className="p-2 text-slate-400 hover:text-red-600 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="text-3xl font-bold text-slate-800">
                {Number(account.balance).toLocaleString('ru-RU', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}{' '}
                {account.currency}
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="glass-card rounded-3xl max-w-md w-full p-8">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent mb-6">
              {editingAccount ? t.accounts.editAccount : t.accounts.newAccount}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  {t.accounts.accountName}
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl glass border-0 focus:ring-2 focus:ring-blue-400 outline-none transition"
                  placeholder={t.accounts.accountName}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">{t.accounts.accountType}</label>
                <select
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value as Account['type'] })
                  }
                  className="w-full px-4 py-3 rounded-xl glass border-0 focus:ring-2 focus:ring-blue-400 outline-none transition"
                >
                  {ACCOUNT_TYPES.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  {t.accounts.initialBalance}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.balance}
                  onChange={(e) => setFormData({ ...formData, balance: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl glass border-0 focus:ring-2 focus:ring-blue-400 outline-none transition"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.accounts.description}</label>
                <div className="flex gap-2 flex-wrap">
                  {COLORS.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData({ ...formData, color })}
                      className={`w-10 h-10 rounded-lg transition ${
                        formData.color === color ? 'ring-2 ring-offset-2 ring-emerald-500' : ''
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 glass text-slate-700 rounded-xl hover:bg-white/60 transition font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 gradient-blue text-white rounded-xl hover:shadow-lg transition-all font-semibold"
                >
                  {editingAccount ? t.update : t.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
