import { useEffect, useState } from 'react';
import { supabase, Account, Category, Transaction } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { TransactionFiles } from './TransactionFiles';
import {
  Plus,
  TrendingUp,
  TrendingDown,
  ArrowRightLeft,
  Filter,
  Folder,
  X,
  Edit2,
  Trash2,
  Paperclip,
} from 'lucide-react';

type TransactionWithDetails = Transaction & {
  account?: Account;
  category?: Category;
  to_account?: Account;
};

export const Transactions = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [transactions, setTransactions] = useState<TransactionWithDetails[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [currentTransactionId, setCurrentTransactionId] = useState<string | null>(null);
  const [showFilesModal, setShowFilesModal] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] = useState<string | null>(null);
  const [editingTransaction, setEditingTransaction] = useState<TransactionWithDetails | null>(null);
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);

  const [formData, setFormData] = useState({
    type: 'expense' as 'income' | 'expense' | 'transfer',
    amount: '',
    account_id: '',
    to_account_id: '',
    category_id: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const [categoryForm, setCategoryForm] = useState({
    name: '',
    type: 'expense' as 'income' | 'expense',
    parent_id: null as string | null,
    color: '#3b82f6',
    icon: 'tag',
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);

    const [accountsRes, categoriesRes, transactionsRes] = await Promise.all([
      supabase.from('accounts').select('*').order('name'),
      supabase.from('categories').select('*').order('name'),
      supabase.from('transactions').select('*').order('date', { ascending: false }).limit(50),
    ]);

    setAccounts(accountsRes.data || []);
    setCategories(categoriesRes.data || []);

    const transactionsWithDetails = (transactionsRes.data || []).map((t) => ({
      ...t,
      account: accountsRes.data?.find((a) => a.id === t.account_id),
      category: categoriesRes.data?.find((c) => c.id === t.category_id),
      to_account: accountsRes.data?.find((a) => a.id === t.to_account_id),
    }));

    setTransactions(transactionsWithDetails);
    setLoading(false);
  };

  const handleEdit = (transaction: TransactionWithDetails) => {
    setEditingTransaction(transaction);
    setFormData({
      type: transaction.type,
      amount: transaction.amount.toString(),
      account_id: transaction.account_id,
      to_account_id: transaction.to_account_id || '',
      category_id: transaction.category_id || '',
      description: transaction.description || '',
      date: transaction.date,
    });
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingTransaction) {
      await handleUpdate();
    } else {
      const transactionData: any = {
        user_id: user!.id,
        type: formData.type,
        amount: Number(formData.amount),
        account_id: formData.account_id,
        description: formData.description,
        date: formData.date,
      };

      if (formData.type === 'transfer') {
        transactionData.to_account_id = formData.to_account_id;
      } else {
        transactionData.category_id = formData.category_id || null;
      }

      const { data: newTransaction } = await supabase
        .from('transactions')
        .insert(transactionData)
        .select()
        .single();

      if (newTransaction) {
        setCurrentTransactionId(newTransaction.id);

        if (pendingFiles.length > 0) {
          await uploadPendingFiles(newTransaction.id);
        }
      }

      const account = accounts.find((a) => a.id === formData.account_id);
      if (account) {
        const newBalance =
          formData.type === 'income'
            ? Number(account.balance) + Number(formData.amount)
            : Number(account.balance) - Number(formData.amount);

        await supabase
          .from('accounts')
          .update({ balance: newBalance, updated_at: new Date().toISOString() })
          .eq('id', account.id);

        if (formData.type === 'transfer' && formData.to_account_id) {
          const toAccount = accounts.find((a) => a.id === formData.to_account_id);
          if (toAccount) {
            await supabase
              .from('accounts')
              .update({
                balance: Number(toAccount.balance) + Number(formData.amount),
                updated_at: new Date().toISOString(),
              })
              .eq('id', toAccount.id);
          }
        }
      }

      resetForm();
      loadData();
    }
  };

  const handleUpdate = async () => {
    if (!editingTransaction) return;

    const oldTransaction = editingTransaction;

    if (oldTransaction.account) {
      const revertAdjustment =
        oldTransaction.type === 'income'
          ? -Number(oldTransaction.amount)
          : Number(oldTransaction.amount);
      await supabase
        .from('accounts')
        .update({
          balance: Number(oldTransaction.account.balance) + revertAdjustment,
          updated_at: new Date().toISOString(),
        })
        .eq('id', oldTransaction.account.id);
    }

    if (oldTransaction.type === 'transfer' && oldTransaction.to_account) {
      await supabase
        .from('accounts')
        .update({
          balance: Number(oldTransaction.to_account.balance) - Number(oldTransaction.amount),
          updated_at: new Date().toISOString(),
        })
        .eq('id', oldTransaction.to_account.id);
    }

    const transactionData: any = {
      type: formData.type,
      amount: Number(formData.amount),
      account_id: formData.account_id,
      description: formData.description,
      date: formData.date,
      to_account_id: null,
      category_id: null,
    };

    if (formData.type === 'transfer') {
      transactionData.to_account_id = formData.to_account_id;
    } else {
      transactionData.category_id = formData.category_id || null;
    }

    await supabase
      .from('transactions')
      .update(transactionData)
      .eq('id', oldTransaction.id);

    const account = accounts.find((a) => a.id === formData.account_id);
    if (account) {
      const newBalance =
        formData.type === 'income'
          ? Number(account.balance) + Number(formData.amount)
          : Number(account.balance) - Number(formData.amount);

      await supabase
        .from('accounts')
        .update({ balance: newBalance, updated_at: new Date().toISOString() })
        .eq('id', account.id);

      if (formData.type === 'transfer' && formData.to_account_id) {
        const toAccount = accounts.find((a) => a.id === formData.to_account_id);
        if (toAccount) {
          await supabase
            .from('accounts')
            .update({
              balance: Number(toAccount.balance) + Number(formData.amount),
              updated_at: new Date().toISOString(),
            })
            .eq('id', toAccount.id);
        }
      }
    }

    resetForm();
    loadData();
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();

    await supabase.from('categories').insert({
      user_id: user!.id,
      name: categoryForm.name,
      type: categoryForm.type,
      parent_id: categoryForm.parent_id,
      color: categoryForm.color,
      icon: categoryForm.icon,
    });

    setCategoryForm({
      name: '',
      type: 'expense',
      parent_id: null,
      color: '#3b82f6',
      icon: 'tag',
    });
    setShowCategoryModal(false);
    loadData();
  };

  const handleDelete = async (id: string, transaction: TransactionWithDetails) => {
    if (confirm(t.transactions.deleteTransactionConfirm)) {
      await supabase.from('transactions').delete().eq('id', id);

      if (transaction.account) {
        const adjustment =
          transaction.type === 'income'
            ? -Number(transaction.amount)
            : Number(transaction.amount);
        await supabase
          .from('accounts')
          .update({
            balance: Number(transaction.account.balance) + adjustment,
            updated_at: new Date().toISOString(),
          })
          .eq('id', transaction.account.id);
      }

      if (transaction.type === 'transfer' && transaction.to_account) {
        await supabase
          .from('accounts')
          .update({
            balance: Number(transaction.to_account.balance) - Number(transaction.amount),
            updated_at: new Date().toISOString(),
          })
          .eq('id', transaction.to_account.id);
      }

      loadData();
    }
  };

  const uploadPendingFiles = async (transactionId: string) => {
    if (!user) return;

    for (const file of pendingFiles) {
      try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('transaction-files')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        await supabase.from('transaction_files').insert({
          transaction_id: transactionId,
          file_name: file.name,
          file_path: filePath,
          file_size: file.size,
          file_type: file.type,
          uploaded_by: user.id,
        });
      } catch (error) {
        console.error('Error uploading file:', error);
      }
    }
    setPendingFiles([]);
  };

  const handlePendingFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newFiles = Array.from(event.target.files);
      setPendingFiles((prev) => [...prev, ...newFiles]);
      event.target.value = '';
    }
  };

  const removePendingFile = (index: number) => {
    setPendingFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setFormData({
      type: 'expense',
      amount: '',
      account_id: '',
      to_account_id: '',
      category_id: '',
      description: '',
      date: new Date().toISOString().split('T')[0],
    });
    setCurrentTransactionId(null);
    setEditingTransaction(null);
    setShowModal(false);
    setPendingFiles([]);
  };

  const handleViewFiles = (transactionId: string) => {
    setSelectedTransactionId(transactionId);
    setShowFilesModal(true);
  };

  const mainCategories = categories.filter((c) => !c.parent_id);
  const getSubcategories = (parentId: string) =>
    categories.filter((c) => c.parent_id === parentId);

  const filteredTransactions =
    filterType === 'all'
      ? transactions
      : transactions.filter((t) => t.type === filterType);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6 gap-2">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-800">{t.transactions.title}</h1>
        <div className="flex gap-2 shrink-0">
          <button
            onClick={() => setShowCategoryModal(true)}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 sm:px-4 py-2 rounded-lg transition"
            title={t.transactions.categories}
          >
            <Folder className="w-5 h-5" />
            <span className="hidden sm:inline">{t.transactions.categories}</span>
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-3 sm:px-4 py-2 rounded-lg transition"
            title={t.transactions.addTransaction}
          >
            <Plus className="w-5 h-5" />
            <span className="hidden sm:inline">{t.transactions.addTransaction}</span>
          </button>
        </div>
      </div>

      <div className="mb-6 flex gap-2 flex-wrap">
        {[
          { value: 'all', label: t.all },
          { value: 'income', label: t.transactions.types.income },
          { value: 'expense', label: t.transactions.types.expense },
          { value: 'transfer', label: t.transactions.types.transfer },
        ].map((type) => (
          <button
            key={type.value}
            onClick={() => setFilterType(type.value)}
            className={`px-4 py-2 rounded-lg transition ${
              filterType === type.value
                ? 'bg-emerald-500 text-white'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {type.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200">
        <div className="divide-y divide-slate-200">
          {filteredTransactions.length === 0 ? (
            <div className="p-12 text-center text-slate-500">{t.transactions.noTransactions}</div>
          ) : (
            filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="p-4 sm:p-6">
                <div className="flex items-start gap-3 sm:gap-4">
                  <div
                    className={`p-2 rounded-lg shrink-0 ${
                      transaction.type === 'income'
                        ? 'bg-green-100'
                        : transaction.type === 'expense'
                        ? 'bg-red-100'
                        : 'bg-blue-100'
                    }`}
                  >
                    {transaction.type === 'income' ? (
                      <TrendingUp className="w-5 h-5 text-green-600" />
                    ) : transaction.type === 'expense' ? (
                      <TrendingDown className="w-5 h-5 text-red-600" />
                    ) : (
                      <ArrowRightLeft className="w-5 h-5 text-blue-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="font-medium text-slate-800 truncate">
                        {transaction.description || t.noDescription}
                      </div>
                      <div
                        className={`text-base sm:text-lg font-semibold shrink-0 ${
                          transaction.type === 'income'
                            ? 'text-green-600'
                            : transaction.type === 'expense'
                            ? 'text-red-600'
                            : 'text-blue-600'
                        }`}
                      >
                        {transaction.type === 'income' ? '+' : transaction.type === 'expense' ? '-' : ''}
                        {Number(transaction.amount).toLocaleString('ru-RU', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })} ₽
                      </div>
                    </div>
                    <div className="text-sm text-slate-500 flex items-center gap-2 flex-wrap mb-2">
                      <span>{new Date(transaction.date).toLocaleDateString('ru-RU')}</span>
                      <span>•</span>
                      <span className="truncate">{transaction.account?.name}</span>
                      {transaction.type === 'transfer' && transaction.to_account && (
                        <>
                          <span>→</span>
                          <span className="truncate">{transaction.to_account.name}</span>
                        </>
                      )}
                      {transaction.category && (
                        <>
                          <span>•</span>
                          <span className="text-xs bg-slate-100 px-2 py-1 rounded">
                            {transaction.category.name}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-1 sm:gap-2">
                      <button
                        onClick={() => handleViewFiles(transaction.id)}
                        className="p-1.5 sm:p-2 text-slate-400 hover:text-blue-600 transition"
                        title={t.transactions.files}
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEdit(transaction)}
                        className="p-1.5 sm:p-2 text-slate-400 hover:text-blue-600 transition"
                        title={t.edit}
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(transaction.id, transaction)}
                        className="p-1.5 sm:p-2 text-slate-400 hover:text-red-600 transition"
                        title={t.delete}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">
              {editingTransaction ? t.transactions.editTransaction : t.transactions.newTransaction}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.type}</label>
                <select
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      type: e.target.value as typeof formData.type,
                    })
                  }
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="expense">{t.transactions.types.expense}</option>
                  <option value="income">{t.transactions.types.income}</option>
                  <option value="transfer">{t.transactions.types.transfer}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.amount}</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  {formData.type === 'transfer' ? t.transactions.fromAccount : t.transactions.account}
                </label>
                <select
                  value={formData.account_id}
                  onChange={(e) => setFormData({ ...formData, account_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                >
                  <option value="">{t.transactions.selectAccount}</option>
                  {accounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.name} ({account.balance} {account.currency})
                    </option>
                  ))}
                </select>
              </div>

              {formData.type === 'transfer' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    {t.transactions.toAccount}
                  </label>
                  <select
                    value={formData.to_account_id}
                    onChange={(e) => setFormData({ ...formData, to_account_id: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                    required
                  >
                    <option value="">{t.transactions.selectAccount}</option>
                    {accounts
                      .filter((a) => a.id !== formData.account_id)
                      .map((account) => (
                        <option key={account.id} value={account.id}>
                          {account.name} ({account.balance} {account.currency})
                        </option>
                      ))}
                  </select>
                </div>
              )}

              {formData.type !== 'transfer' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    {t.transactions.category}
                  </label>
                  <select
                    value={formData.category_id}
                    onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">{t.transactions.noCategory}</option>
                    {mainCategories
                      .filter((c) => c.type === formData.type)
                      .map((category) => (
                        <>
                          <option key={category.id} value={category.id}>
                            {category.name}
                          </option>
                          {getSubcategories(category.id).map((sub) => (
                            <option key={sub.id} value={sub.id}>
                              → {sub.name}
                            </option>
                          ))}
                        </>
                      ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  {t.transactions.description}
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                  rows={1}
                  placeholder={t.transactions.descriptionPlaceholder}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t.transactions.date}</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="pt-4 border-t border-slate-200">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-sm font-medium text-slate-700">
                      <Paperclip className="w-4 h-4 inline mr-1" />
                      {t.transactions.attachments}
                    </label>
                  </div>

                  {!editingTransaction && !currentTransactionId && (
                    <div>
                      <input
                        type="file"
                        id="pending-file-upload"
                        onChange={handlePendingFileSelect}
                        className="hidden"
                        multiple
                      />
                      <label
                        htmlFor="pending-file-upload"
                        className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-50 hover:bg-slate-100 border-2 border-dashed border-slate-300 rounded-lg cursor-pointer transition text-sm text-slate-600"
                      >
                        <Paperclip className="w-4 h-4" />
                        {t.transactions.attachFiles}
                      </label>

                      {pendingFiles.length > 0 && (
                        <div className="mt-3 space-y-2">
                          {pendingFiles.map((file, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-2 bg-slate-50 rounded-lg"
                            >
                              <div className="flex items-center gap-2 flex-1 min-w-0">
                                <Paperclip className="w-4 h-4 text-slate-400 shrink-0" />
                                <span className="text-sm text-slate-700 truncate">{file.name}</span>
                                <span className="text-xs text-slate-500 shrink-0">
                                  ({(file.size / 1024).toFixed(1)} KB)
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => removePendingFile(index)}
                                className="p-1 hover:bg-red-100 text-red-600 rounded transition shrink-0"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {(currentTransactionId || editingTransaction?.id) && (
                    <TransactionFiles transactionId={currentTransactionId || editingTransaction?.id || null} />
                  )}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition"
                >
                  {editingTransaction ? t.update : t.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showCategoryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-800">{t.transactions.manageCategories}</h2>
              <button
                onClick={() => setShowCategoryModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateCategory} className="space-y-4 mb-6 p-4 bg-slate-50 rounded-lg">
              <h3 className="font-semibold text-slate-800">{t.transactions.createNewCategory}</h3>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  className="px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  placeholder={t.transactions.categoryName}
                  required
                />
                <select
                  value={categoryForm.type}
                  onChange={(e) =>
                    setCategoryForm({
                      ...categoryForm,
                      type: e.target.value as 'income' | 'expense',
                    })
                  }
                  className="px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="expense">{t.transactions.types.expense}</option>
                  <option value="income">{t.transactions.types.income}</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  {t.transactions.parentCategory}
                </label>
                <select
                  value={categoryForm.parent_id || ''}
                  onChange={(e) =>
                    setCategoryForm({
                      ...categoryForm,
                      parent_id: e.target.value || null,
                    })
                  }
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="">{t.transactions.noneMainCategory}</option>
                  {mainCategories
                    .filter((c) => c.type === categoryForm.type)
                    .map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                </select>
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition"
              >
                {t.transactions.addCategory}
              </button>
            </form>

            <div className="space-y-4">
              <h3 className="font-semibold text-slate-800">{t.transactions.existingCategories}</h3>
              {mainCategories.map((category) => (
                <div key={category.id} className="border border-slate-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: category.color }}
                      />
                      <span className="font-medium">{category.name}</span>
                      <span
                        className={`text-xs px-2 py-1 rounded ${
                          category.type === 'income'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {category.type}
                      </span>
                    </div>
                  </div>
                  {getSubcategories(category.id).length > 0 && (
                    <div className="ml-6 mt-2 space-y-1">
                      {getSubcategories(category.id).map((sub) => (
                        <div key={sub.id} className="text-sm text-slate-600">
                          → {sub.name}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showFilesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-800">{t.transactions.attachments}</h2>
              <button
                onClick={() => {
                  setShowFilesModal(false);
                  setSelectedTransactionId(null);
                }}
                className="p-2 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <TransactionFiles transactionId={selectedTransactionId} />
          </div>
        </div>
      )}
    </div>
  );
};
