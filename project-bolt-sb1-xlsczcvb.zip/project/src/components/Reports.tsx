import { useEffect, useState } from 'react';
import { supabase, Transaction, Category } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { BarChart3, PieChart, TrendingUp, Search, Sparkles } from 'lucide-react';

type ChartData = {
  label: string;
  value: number;
  color: string;
};

export const Reports = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [reportData, setReportData] = useState<ChartData[] | null>(null);
  const [reportTitle, setReportTitle] = useState('');
  const [reportType, setReportType] = useState<'bar' | 'pie'>('bar');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    const [transactionsRes, categoriesRes] = await Promise.all([
      supabase.from('transactions').select('*'),
      supabase.from('categories').select('*'),
    ]);

    setTransactions(transactionsRes.data || []);
    setCategories(categoriesRes.data || []);
    setLoading(false);
  };

  const generateReport = () => {
    if (!query.trim()) return;

    const lowerQuery = query.toLowerCase();
    let data: ChartData[] = [];
    let title = '';

    if (lowerQuery.includes('категори') || lowerQuery.includes('category')) {
      const categoryExpenses = new Map<string, number>();

      transactions
        .filter((t) => t.type === 'expense' && t.category_id)
        .forEach((t) => {
          const category = categories.find((c) => c.id === t.category_id);
          if (category) {
            const current = categoryExpenses.get(category.name) || 0;
            categoryExpenses.set(category.name, current + Number(t.amount));
          }
        });

      data = Array.from(categoryExpenses.entries())
        .map(([label, value]) => {
          const category = categories.find((c) => c.name === label);
          return {
            label,
            value,
            color: category?.color || '#3b82f6',
          };
        })
        .sort((a, b) => b.value - a.value)
        .slice(0, 10);

      title = 'Expenses by Category';
      setReportType('pie');
    } else if (lowerQuery.includes('месяц') || lowerQuery.includes('month')) {
      const monthlyData = new Map<string, number>();

      transactions.forEach((t) => {
        const date = new Date(t.date);
        const monthKey = date.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });
        const current = monthlyData.get(monthKey) || 0;

        if (t.type === 'expense') {
          monthlyData.set(monthKey, current + Number(t.amount));
        }
      });

      data = Array.from(monthlyData.entries())
        .map(([label, value]) => ({ label, value, color: '#ef4444' }))
        .sort((a, b) => a.label.localeCompare(b.label))
        .slice(-6);

      title = 'Monthly Expenses';
      setReportType('bar');
    } else if (
      lowerQuery.includes('такси') ||
      lowerQuery.includes('taxi') ||
      categories.some((c) => lowerQuery.includes(c.name.toLowerCase()))
    ) {
      const targetCategory = categories.find((c) =>
        lowerQuery.includes(c.name.toLowerCase())
      );

      if (targetCategory) {
        const monthlyData = new Map<string, number>();

        transactions
          .filter((t) => t.category_id === targetCategory.id)
          .forEach((t) => {
            const date = new Date(t.date);
            const monthKey = date.toLocaleDateString('ru-RU', { month: 'short' });
            const current = monthlyData.get(monthKey) || 0;
            monthlyData.set(monthKey, current + Number(t.amount));
          });

        data = Array.from(monthlyData.entries())
          .map(([label, value]) => ({ label, value, color: targetCategory.color }))
          .sort((a, b) => a.label.localeCompare(b.label));

        title = `${targetCategory.name} - Monthly Trend`;
        setReportType('bar');
      }
    } else if (lowerQuery.includes('доход') || lowerQuery.includes('income')) {
      const monthlyData = new Map<string, { income: number; expense: number }>();

      transactions.forEach((t) => {
        const date = new Date(t.date);
        const monthKey = date.toLocaleDateString('ru-RU', { month: 'short' });
        const current = monthlyData.get(monthKey) || { income: 0, expense: 0 };

        if (t.type === 'income') {
          current.income += Number(t.amount);
        } else if (t.type === 'expense') {
          current.expense += Number(t.amount);
        }

        monthlyData.set(monthKey, current);
      });

      data = Array.from(monthlyData.entries())
        .map(([label, values]) => ({
          label,
          value: values.income - values.expense,
          color: values.income > values.expense ? '#10b981' : '#ef4444',
        }))
        .sort((a, b) => a.label.localeCompare(b.label))
        .slice(-6);

      title = 'Net Income (Income - Expenses)';
      setReportType('bar');
    } else {
      const recentMonths = new Map<string, number>();

      transactions
        .filter((t) => t.type === 'expense')
        .slice(-50)
        .forEach((t) => {
          const date = new Date(t.date);
          const monthKey = date.toLocaleDateString('ru-RU', { month: 'short' });
          const current = recentMonths.get(monthKey) || 0;
          recentMonths.set(monthKey, current + Number(t.amount));
        });

      data = Array.from(recentMonths.entries())
        .map(([label, value]) => ({ label, value, color: '#ef4444' }))
        .sort((a, b) => a.label.localeCompare(b.label));

      title = 'Recent Expenses Overview';
      setReportType('bar');
    }

    setReportData(data);
    setReportTitle(title);
  };

  const renderBarChart = (data: ChartData[]) => {
    if (data.length === 0) return null;

    const maxValue = Math.max(...data.map((d) => d.value));
    const chartHeight = 300;
    const barWidth = 60;
    const gap = 20;

    return (
      <div className="overflow-x-auto">
        <svg
          width={Math.max(600, data.length * (barWidth + gap) + 40)}
          height={chartHeight + 80}
          className="mx-auto"
        >
          {data.map((item, index) => {
            const barHeight = (item.value / maxValue) * chartHeight;
            const x = 20 + index * (barWidth + gap);
            const y = chartHeight - barHeight + 20;

            return (
              <g key={index}>
                <rect
                  x={x}
                  y={y}
                  width={barWidth}
                  height={barHeight}
                  fill={item.color}
                  rx={4}
                  className="transition-all duration-300 hover:opacity-80"
                />
                <text
                  x={x + barWidth / 2}
                  y={y - 10}
                  textAnchor="middle"
                  className="text-sm font-semibold fill-slate-700"
                >
                  {item.value.toLocaleString('ru-RU', {
                    maximumFractionDigits: 0,
                  })}
                </text>
                <text
                  x={x + barWidth / 2}
                  y={chartHeight + 40}
                  textAnchor="middle"
                  className="text-xs fill-slate-600"
                >
                  {item.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    );
  };

  const renderPieChart = (data: ChartData[]) => {
    if (data.length === 0) return null;

    const total = data.reduce((sum, d) => sum + d.value, 0);
    const centerX = 200;
    const centerY = 200;
    const radius = 150;

    let currentAngle = -90;
    const slices = data.map((item) => {
      const angle = (item.value / total) * 360;
      const startAngle = currentAngle;
      const endAngle = currentAngle + angle;
      currentAngle = endAngle;

      const startRad = (startAngle * Math.PI) / 180;
      const endRad = (endAngle * Math.PI) / 180;

      const x1 = centerX + radius * Math.cos(startRad);
      const y1 = centerY + radius * Math.sin(startRad);
      const x2 = centerX + radius * Math.cos(endRad);
      const y2 = centerY + radius * Math.sin(endRad);

      const largeArc = angle > 180 ? 1 : 0;

      const path = `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;

      return { ...item, path, percentage: (item.value / total) * 100 };
    });

    return (
      <div className="flex flex-col lg:flex-row items-center gap-8">
        <svg width={400} height={400} className="flex-shrink-0">
          {slices.map((slice, index) => (
            <path
              key={index}
              d={slice.path}
              fill={slice.color}
              className="transition-all duration-300 hover:opacity-80"
            />
          ))}
        </svg>

        <div className="flex-1 space-y-2 w-full">
          {slices.map((slice, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: slice.color }} />
                <span className="font-medium text-slate-800">{slice.label}</span>
              </div>
              <div className="text-right">
                <div className="font-semibold text-slate-800">
                  {slice.value.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽
                </div>
                <div className="text-sm text-slate-500">{slice.percentage.toFixed(1)}%</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">{t.reports.title}</h1>
        <p className="text-slate-600">
          {t.reports.subtitle}
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && generateReport()}
              className="w-full px-4 py-3 pl-12 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none"
              placeholder={t.reports.placeholder}
            />
            <Sparkles className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>
          <button
            onClick={generateReport}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-lg transition"
          >
            <Search className="w-5 h-5" />
            {t.reports.generate}
          </button>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => {
              setQuery('show expenses by category');
              setTimeout(generateReport, 100);
            }}
            className="text-sm px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition"
          >
            {t.reports.examples.byCategory}
          </button>
          <button
            onClick={() => {
              setQuery('monthly expenses');
              setTimeout(generateReport, 100);
            }}
            className="text-sm px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition"
          >
            {t.reports.examples.monthly}
          </button>
          <button
            onClick={() => {
              setQuery('income vs expenses');
              setTimeout(generateReport, 100);
            }}
            className="text-sm px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition"
          >
            {t.reports.examples.incomeVsExpenses}
          </button>
        </div>
      </div>

      {reportData && reportData.length > 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-800">{reportTitle}</h2>
            <div className="flex gap-2">
              <button
                onClick={() => setReportType('bar')}
                className={`p-2 rounded-lg transition ${
                  reportType === 'bar'
                    ? 'bg-emerald-100 text-emerald-600'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <BarChart3 className="w-5 h-5" />
              </button>
              <button
                onClick={() => setReportType('pie')}
                className={`p-2 rounded-lg transition ${
                  reportType === 'pie'
                    ? 'bg-emerald-100 text-emerald-600'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <PieChart className="w-5 h-5" />
              </button>
            </div>
          </div>

          {reportType === 'bar' ? renderBarChart(reportData) : renderPieChart(reportData)}

          <div className="mt-6 p-4 bg-slate-50 rounded-lg">
            <h3 className="font-semibold text-slate-800 mb-2">{t.reports.summary}</h3>
            <div className="text-sm text-slate-600">
              <p>
                {t.reports.total}:{' '}
                <span className="font-semibold text-slate-800">
                  {reportData
                    .reduce((sum, d) => sum + d.value, 0)
                    .toLocaleString('ru-RU', { maximumFractionDigits: 0 })}{' '}
                  ₽
                </span>
              </p>
              <p>
                {t.reports.average}:{' '}
                <span className="font-semibold text-slate-800">
                  {(
                    reportData.reduce((sum, d) => sum + d.value, 0) / reportData.length
                  ).toLocaleString('ru-RU', { maximumFractionDigits: 0 })}{' '}
                  ₽
                </span>
              </p>
            </div>
          </div>
        </div>
      ) : reportData !== null ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center text-slate-500">
          {t.reports.noData}
        </div>
      ) : null}
    </div>
  );
};
