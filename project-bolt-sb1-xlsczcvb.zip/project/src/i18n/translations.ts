export type Language = 'en' | 'ru';

export interface Translations {
  // Common
  appName: string;
  signOut: string;
  cancel: string;
  save: string;
  delete: string;
  edit: string;
  add: string;
  search: string;
  filter: string;
  loading: string;
  create: string;
  update: string;
  new: string;
  yes: string;
  no: string;
  all: string;
  noDescription: string;

  // Navigation
  nav: {
    dashboard: string;
    accounts: string;
    transactions: string;
    planned: string;
    reports: string;
  };

  // Auth
  auth: {
    signIn: string;
    signUp: string;
    email: string;
    password: string;
    confirmPassword: string;
    alreadyHaveAccount: string;
    dontHaveAccount: string;
    signInButton: string;
    signUpButton: string;
  };

  // Dashboard
  dashboard: {
    totalBalance: string;
    incomeThisMonth: string;
    expensesThisMonth: string;
    noAccounts: string;
    noAccountsDescription: string;
    recentTransactions: string;
    noTransactions: string;
  };

  // Accounts
  accounts: {
    title: string;
    addAccount: string;
    accountName: string;
    accountType: string;
    initialBalance: string;
    currency: string;
    description: string;
    newAccount: string;
    editAccount: string;
    deleteAccountConfirm: string;
    types: {
      cash: string;
      bank: string;
      card: string;
      savings: string;
      investment: string;
      deposit: string;
    };
    noAccounts: string;
    balance: string;
  };

  // Transactions
  transactions: {
    title: string;
    addTransaction: string;
    newTransaction: string;
    editTransaction: string;
    manageCategories: string;
    categories: string;
    type: string;
    amount: string;
    category: string;
    account: string;
    toAccount: string;
    fromAccount: string;
    date: string;
    description: string;
    descriptionPlaceholder: string;
    attachments: string;
    addFile: string;
    attachFiles: string;
    files: string;
    noFiles: string;
    saveToAttach: string;
    uploadFile: string;
    downloadFile: string;
    deleteFile: string;
    fileSize: string;
    deleteTransactionConfirm: string;
    noCategory: string;
    createNewCategory: string;
    categoryName: string;
    parentCategory: string;
    noneMainCategory: string;
    addCategory: string;
    existingCategories: string;
    types: {
      income: string;
      expense: string;
      transfer: string;
    };
    noTransactions: string;
    selectAccount: string;
    selectCategory: string;
  };

  // Planned
  planned: {
    title: string;
    addPlanned: string;
    newPlanned: string;
    budgets: string;
    incomeBudgets: string;
    plannedTransactions: string;
    noBudgets: string;
    noIncomeBudgets: string;
    noPlanned: string;
    newPlannedTransaction: string;
    newBudget: string;
    newIncomeBudget: string;
    deletePlannedConfirm: string;
    plannedDate: string;
    complete: string;
    of: string;
    used: string;
    received: string;
    frequency: {
      once: string;
      daily: string;
      weekly: string;
      monthly: string;
      yearly: string;
    };
    nextDate: string;
    lastExecuted: string;
    budget: string;
    spent: string;
    remaining: string;
    month: string;
  };

  // Reports
  reports: {
    title: string;
    subtitle: string;
    generate: string;
    placeholder: string;
    summary: string;
    total: string;
    average: string;
    noData: string;
    period: string;
    thisMonth: string;
    lastMonth: string;
    thisYear: string;
    custom: string;
    incomeVsExpenses: string;
    byCategory: string;
    searchPlaceholder: string;
    noDataForQuery: string;
    expensesByCategory: string;
    monthlyTrend: string;
    examples: {
      byCategory: string;
      monthly: string;
      incomeVsExpenses: string;
    };
  };

  // Version
  version: {
    title: string;
    viewChangelog: string;
    incomeTracking: string;
    budgetSubcategories: string;
    bugFixes: string;
    fileAttachments: string;
    aiReports: string;
    majorFeatures: string;
    changes125: {
      item1: string;
      item2: string;
      item3: string;
      item4: string;
    };
    changes124: {
      item1: string;
      item2: string;
      item3: string;
    };
    changes123: {
      item1: string;
      item2: string;
    };
    changes122: {
      item1: string;
      item2: string;
    };
    changes121: {
      item1: string;
      item2: string;
    };
    changes120: {
      item1: string;
      item2: string;
      item3: string;
    };
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'Home Accounting',
    signOut: 'Sign Out',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    filter: 'Filter',
    loading: 'Loading...',
    create: 'Create',
    update: 'Update',
    new: 'New',
    yes: 'Yes',
    no: 'No',
    all: 'All',
    noDescription: 'No description',

    nav: {
      dashboard: 'Dashboard',
      accounts: 'Accounts',
      transactions: 'Transactions',
      planned: 'Planned',
      reports: 'Reports',
    },

    auth: {
      signIn: 'Sign In',
      signUp: 'Sign Up',
      email: 'Email',
      password: 'Password',
      confirmPassword: 'Confirm Password',
      alreadyHaveAccount: 'Already have an account?',
      dontHaveAccount: "Don't have an account?",
      signInButton: 'Sign In',
      signUpButton: 'Create Account',
    },

    dashboard: {
      totalBalance: 'Total Balance',
      incomeThisMonth: 'Income This Month',
      expensesThisMonth: 'Expenses This Month',
      noAccounts: 'No accounts yet',
      noAccountsDescription: 'Create your first account to start tracking your finances.',
      recentTransactions: 'Recent Transactions',
      noTransactions: 'No transactions yet',
    },

    accounts: {
      title: 'Accounts',
      addAccount: 'Add Account',
      accountName: 'Account Name',
      accountType: 'Account Type',
      initialBalance: 'Initial Balance',
      currency: 'Currency',
      description: 'Description',
      newAccount: 'New Account',
      editAccount: 'Edit Account',
      deleteAccountConfirm: 'Are you sure you want to delete this account?',
      types: {
        cash: 'Cash',
        bank: 'Bank Account',
        card: 'Card',
        savings: 'Savings',
        investment: 'Investment',
        deposit: 'Deposit',
      },
      noAccounts: 'No accounts yet. Create your first account to get started.',
      balance: 'Balance',
    },

    transactions: {
      title: 'Transactions',
      addTransaction: 'Add Transaction',
      newTransaction: 'New Transaction',
      editTransaction: 'Edit Transaction',
      manageCategories: 'Manage Categories',
      categories: 'Categories',
      type: 'Type',
      amount: 'Amount',
      category: 'Category',
      account: 'Account',
      toAccount: 'To Account',
      fromAccount: 'From Account',
      date: 'Date',
      description: 'Description',
      descriptionPlaceholder: 'Optional description',
      attachments: 'Attachments',
      addFile: 'Add File',
      attachFiles: 'Click or drag files here',
      files: 'Files',
      noFiles: 'No files attached',
      saveToAttach: 'Save the transaction first to attach files',
      uploadFile: 'Upload File',
      downloadFile: 'Download',
      deleteFile: 'Delete File',
      fileSize: 'Size',
      deleteTransactionConfirm: 'Delete this transaction?',
      noCategory: 'No category',
      createNewCategory: 'Create New Category',
      categoryName: 'Category name',
      parentCategory: 'Parent Category (optional)',
      noneMainCategory: 'None (Main Category)',
      addCategory: 'Add Category',
      existingCategories: 'Existing Categories',
      types: {
        income: 'Income',
        expense: 'Expense',
        transfer: 'Transfer',
      },
      noTransactions: 'No transactions yet. Add your first transaction to start tracking.',
      selectAccount: 'Select account',
      selectCategory: 'Select category',
    },

    planned: {
      title: 'Planning & Budgets',
      addPlanned: 'Add Planned Transaction',
      newPlanned: 'New Planned Transaction',
      budgets: 'Budgets',
      incomeBudgets: 'Income',
      plannedTransactions: 'Planned Transactions',
      noBudgets: 'No budgets set',
      noIncomeBudgets: 'No income budgets set',
      noPlanned: 'No planned transactions',
      newPlannedTransaction: 'New Planned Transaction',
      newBudget: 'New Budget',
      newIncomeBudget: 'New Income Budget',
      deletePlannedConfirm: 'Delete this planned transaction?',
      plannedDate: 'Planned Date',
      complete: 'Complete',
      of: 'of',
      used: 'used',
      received: 'received',
      frequency: {
        once: 'Once',
        daily: 'Daily',
        weekly: 'Weekly',
        monthly: 'Monthly',
        yearly: 'Yearly',
      },
      nextDate: 'Next Date',
      lastExecuted: 'Last Executed',
      budget: 'Budget',
      spent: 'Spent',
      remaining: 'Remaining',
      month: 'Month',
    },

    reports: {
      title: 'AI Reports',
      subtitle: 'Ask questions about your spending and get instant visual reports',
      generate: 'Generate',
      placeholder: "e.g., 'show expenses by category', 'monthly taxi expenses', 'income vs expenses'",
      summary: 'Summary',
      total: 'Total',
      average: 'Average',
      noData: 'No data found for your query. Try a different search.',
      period: 'Period',
      thisMonth: 'This Month',
      lastMonth: 'Last Month',
      thisYear: 'This Year',
      custom: 'Custom',
      incomeVsExpenses: 'Income vs Expenses',
      byCategory: 'By Category',
      searchPlaceholder: 'Try: "expenses by category", "income trends", "spending on food"...',
      noDataForQuery: 'No data found for your query. Try a different search.',
      expensesByCategory: 'Expenses by Category',
      monthlyTrend: 'Monthly Trend',
      examples: {
        byCategory: 'Expenses by category',
        monthly: 'Monthly expenses',
        incomeVsExpenses: 'Income vs expenses',
      },
    },

    version: {
      title: 'Version History',
      viewChangelog: 'View changelog',
      incomeTracking: 'Income Tracking (Поступления)',
      budgetSubcategories: 'Budget Subcategories & File Attachments',
      bugFixes: 'Bug Fixes & Improvements',
      fileAttachments: 'File Attachments',
      aiReports: 'AI-Powered Reports',
      majorFeatures: 'Major Features',
      changes125: {
        item1: 'New "Income" tab for tracking expected income',
        item2: 'Plan expected income by category for each month',
        item3: 'Track received income with progress bars',
        item4: 'Support for income categories and subcategories',
      },
      changes124: {
        item1: 'Budget support for subcategories with hierarchy tracking',
        item2: 'Pre-upload file attachments with drag-and-drop',
        item3: 'Improved file management workflow',
      },
      changes123: {
        item1: 'Fixed dynamic budget spending calculation',
        item2: 'Fixed modal forms overflow on mobile',
      },
      changes122: {
        item1: 'Added file attachment support for transactions',
        item2: 'Upload and view receipts, invoices, and documents',
      },
      changes121: {
        item1: 'AI-powered natural language reports',
        item2: 'Dynamic charts and expense analysis',
      },
      changes120: {
        item1: 'Planning & Budgets system',
        item2: 'Planned transactions scheduling',
        item3: 'Monthly budget tracking',
      },
    },
  },

  ru: {
    appName: 'Домашняя Бухгалтерия',
    signOut: 'Выход',
    cancel: 'Отмена',
    save: 'Сохранить',
    delete: 'Удалить',
    edit: 'Редактировать',
    add: 'Добавить',
    search: 'Поиск',
    filter: 'Фильтр',
    loading: 'Загрузка...',
    create: 'Создать',
    update: 'Обновить',
    new: 'Новый',
    yes: 'Да',
    no: 'Нет',
    all: 'Все',
    noDescription: 'Без описания',

    nav: {
      dashboard: 'Панель',
      accounts: 'Счета',
      transactions: 'Транзакции',
      planned: 'Запланировано',
      reports: 'Отчёты',
    },

    auth: {
      signIn: 'Вход',
      signUp: 'Регистрация',
      email: 'Email',
      password: 'Пароль',
      confirmPassword: 'Подтвердите пароль',
      alreadyHaveAccount: 'Уже есть аккаунт?',
      dontHaveAccount: 'Нет аккаунта?',
      signInButton: 'Войти',
      signUpButton: 'Создать аккаунт',
    },

    dashboard: {
      totalBalance: 'Общий баланс',
      incomeThisMonth: 'Доходы за месяц',
      expensesThisMonth: 'Расходы за месяц',
      noAccounts: 'Нет счетов',
      noAccountsDescription: 'Создайте первый счёт, чтобы начать отслеживать финансы.',
      recentTransactions: 'Последние транзакции',
      noTransactions: 'Нет транзакций',
    },

    accounts: {
      title: 'Счета',
      addAccount: 'Добавить счёт',
      accountName: 'Название счёта',
      accountType: 'Тип счёта',
      initialBalance: 'Начальный баланс',
      currency: 'Валюта',
      description: 'Описание',
      newAccount: 'Новый счёт',
      editAccount: 'Редактировать счёт',
      deleteAccountConfirm: 'Вы уверены, что хотите удалить этот счёт?',
      types: {
        cash: 'Наличные',
        bank: 'Банковский счёт',
        card: 'Карта',
        savings: 'Накопления',
        investment: 'Инвестиции',
        deposit: 'Депозит',
      },
      noAccounts: 'Нет счетов. Создайте первый счёт для начала работы.',
      balance: 'Баланс',
    },

    transactions: {
      title: 'Транзакции',
      addTransaction: 'Добавить транзакцию',
      newTransaction: 'Новая транзакция',
      editTransaction: 'Редактировать транзакцию',
      manageCategories: 'Управление категориями',
      categories: 'Категории',
      type: 'Тип',
      amount: 'Сумма',
      category: 'Категория',
      account: 'Счёт',
      toAccount: 'На счёт',
      fromAccount: 'Со счёта',
      date: 'Дата',
      description: 'Описание',
      descriptionPlaceholder: 'Необязательное описание',
      attachments: 'Вложения',
      addFile: 'Добавить файл',
      attachFiles: 'Нажмите или перетащите файлы сюда',
      files: 'Файлы',
      noFiles: 'Нет прикреплённых файлов',
      saveToAttach: 'Сохраните транзакцию, чтобы прикрепить файлы',
      uploadFile: 'Загрузить файл',
      downloadFile: 'Скачать',
      deleteFile: 'Удалить файл',
      fileSize: 'Размер',
      deleteTransactionConfirm: 'Удалить эту транзакцию?',
      noCategory: 'Без категории',
      createNewCategory: 'Создать новую категорию',
      categoryName: 'Название категории',
      parentCategory: 'Родительская категория (необязательно)',
      noneMainCategory: 'Нет (Главная категория)',
      addCategory: 'Добавить категорию',
      existingCategories: 'Существующие категории',
      types: {
        income: 'Доход',
        expense: 'Расход',
        transfer: 'Перевод',
      },
      noTransactions: 'Нет транзакций. Добавьте первую транзакцию для начала отслеживания.',
      selectAccount: 'Выберите счёт',
      selectCategory: 'Выберите категорию',
    },

    planned: {
      title: 'Запланировано и бюджеты',
      addPlanned: 'Добавить плановую транзакцию',
      newPlanned: 'Новая плановая транзакция',
      budgets: 'Бюджеты',
      incomeBudgets: 'Поступления',
      plannedTransactions: 'Плановые транзакции',
      noBudgets: 'Нет бюджетов',
      noIncomeBudgets: 'Нет плановых поступлений',
      noPlanned: 'Нет плановых транзакций',
      newPlannedTransaction: 'Новая плановая транзакция',
      newBudget: 'Новый бюджет',
      newIncomeBudget: 'Новое поступление',
      deletePlannedConfirm: 'Удалить эту плановую транзакцию?',
      plannedDate: 'Плановая дата',
      complete: 'Выполнить',
      of: 'из',
      used: 'использовано',
      received: 'получено',
      frequency: {
        once: 'Однократно',
        daily: 'Ежедневно',
        weekly: 'Еженедельно',
        monthly: 'Ежемесячно',
        yearly: 'Ежегодно',
      },
      nextDate: 'Следующая дата',
      lastExecuted: 'Последнее выполнение',
      budget: 'Бюджет',
      spent: 'Потрачено',
      remaining: 'Осталось',
      month: 'Месяц',
    },

    reports: {
      title: 'AI Отчёты',
      subtitle: 'Задавайте вопросы о ваших расходах и получайте мгновенные визуальные отчёты',
      generate: 'Создать',
      placeholder: 'напр., "покажи расходы по категориям", "ежемесячные расходы на такси", "доходы и расходы"',
      summary: 'Итого',
      total: 'Всего',
      average: 'Среднее',
      noData: 'Нет данных по вашему запросу. Попробуйте другой поиск.',
      period: 'Период',
      thisMonth: 'Текущий месяц',
      lastMonth: 'Прошлый месяц',
      thisYear: 'Текущий год',
      custom: 'Произвольный',
      incomeVsExpenses: 'Доходы и расходы',
      byCategory: 'По категориям',
      searchPlaceholder: 'Попробуйте: "расходы по категориям", "тренды доходов", "траты на еду"...',
      noDataForQuery: 'Нет данных по вашему запросу. Попробуйте другой поиск.',
      expensesByCategory: 'Расходы по категориям',
      monthlyTrend: 'Тренд по месяцам',
      examples: {
        byCategory: 'Расходы по категориям',
        monthly: 'Ежемесячные расходы',
        incomeVsExpenses: 'Доходы и расходы',
      },
    },

    version: {
      title: 'История версий',
      viewChangelog: 'Посмотреть историю изменений',
      incomeTracking: 'Отслеживание поступлений',
      budgetSubcategories: 'Подкатегории бюджета и вложения файлов',
      bugFixes: 'Исправления ошибок',
      fileAttachments: 'Вложения файлов',
      aiReports: 'AI отчёты',
      majorFeatures: 'Основные функции',
      changes125: {
        item1: 'Новая вкладка "Поступления" для отслеживания ожидаемых доходов',
        item2: 'Планирование ожидаемых доходов по категориям на каждый месяц',
        item3: 'Отслеживание полученных доходов с прогресс-барами',
        item4: 'Поддержка категорий и подкатегорий доходов',
      },
      changes124: {
        item1: 'Поддержка подкатегорий в бюджетах с отслеживанием иерархии',
        item2: 'Прикрепление файлов перед созданием транзакции с drag-and-drop',
        item3: 'Улучшенный процесс работы с файлами',
      },
      changes123: {
        item1: 'Исправлен динамический расчёт расходов бюджета',
        item2: 'Исправлено переполнение модальных форм на мобильных',
      },
      changes122: {
        item1: 'Добавлена поддержка вложений файлов к транзакциям',
        item2: 'Загрузка и просмотр чеков, счетов и документов',
      },
      changes121: {
        item1: 'AI отчёты на естественном языке',
        item2: 'Динамические графики и анализ расходов',
      },
      changes120: {
        item1: 'Система планирования и бюджетов',
        item2: 'Планирование будущих транзакций',
        item3: 'Отслеживание месячных бюджетов',
      },
    },
  },
};
