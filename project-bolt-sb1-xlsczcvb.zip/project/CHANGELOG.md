# Changelog

All notable changes to the Home Accounting project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.5] - 2025-12-07

### Income Tracking (Поступления)

#### Added
- Income budget tracking system:
  - New "Поступления" (Income) tab for tracking expected income
  - Plan expected income by category for each month
  - Track how much income has been received vs planned
  - Support for both main categories and subcategories
  - Automatic hierarchy tracking (main category includes all subcategories)
  - Real-time progress bars showing received percentage
  - Visual progress indicators with emerald green color scheme
  - Example: Plan 100,000₽ income (40,000₽ advance + 60,000₽ final payment)
  - Dynamic updates as income transactions are created

#### Changed
- Added new database table `income_budgets` for income planning
- Extended UI with third tab "Поступления" in Planning & Budgets section
- Added translations for income tracking in Russian and English

#### Impact
- Complete income planning and tracking capability
- Better financial planning with both expense budgets and income tracking
- Symmetrical feature set for managing both inflows and outflows
- More comprehensive financial overview

## [1.2.4] - 2025-12-07

### Budget Subcategories & Pre-Upload File Attachments

#### Added
- Budget subcategory support:
  - Budgets can now be created for both main categories and subcategories
  - When a budget is set for a main category, it automatically tracks all subcategories
  - When a budget is set for a specific subcategory, it tracks only that subcategory
  - Budget form now shows all categories and subcategories with clear hierarchy
  - Subcategories displayed with arrow notation (Parent → Child)
- File attachment before transaction creation:
  - Files can now be attached BEFORE clicking the create button
  - New intuitive drag-and-drop interface for file selection
  - Multiple files can be selected at once
  - File preview with name and size before upload
  - Remove unwanted files before creating transaction
  - Files automatically upload after transaction is created

#### Changed
- Budget calculation logic enhanced to support category hierarchies
- Transaction form now shows file attachment UI immediately
- Improved file attachment workflow with better user experience

#### Impact
- More flexible budget management with subcategory granularity
- Faster transaction creation with pre-selected files
- Better file management experience
- More intuitive budget tracking for complex category structures

## [1.2.3] - 2025-12-07

### Budget Tracking & Modal Forms Fix

#### Fixed
- Budget spending calculation now updates dynamically:
  - Budgets now properly track expenses from transactions in real-time
  - Spent amount updates immediately when new transactions are created
  - Progress bars reflect current spending accurately
  - No need to refresh page to see budget changes
- Modal forms no longer overflow on mobile devices:
  - Added scrolling to planned transaction and budget forms
  - Forms now properly fit within viewport on all devices
  - Better mobile experience with max-height constraints
  - Consistent behavior across all modal dialogs

#### Changed
- Transactions now load together with budgets data for better performance
- Removed redundant transaction loading logic
- Improved data synchronization across components

#### Impact
- Accurate real-time budget tracking
- Better user experience on mobile devices
- Improved form usability on small screens
- More responsive budget management

## [1.2.2] - 2025-12-07

### Mobile UX & Transaction Form Improvements

#### Fixed
- Transaction list display on iPhone 14 Plus and Pro Max in PWA mode:
  - Elements no longer overlap each other
  - Improved vertical spacing with responsive padding (p-4 on mobile, p-6 on desktop)
  - Transaction amount moved to same line as description with proper shrink handling
  - Action buttons moved to separate row below transaction details
  - Added text truncation for long account names and descriptions
  - Better gap spacing between elements (gap-1 on mobile, gap-2 on desktop)
  - Icon container now uses shrink-0 to prevent squashing
- File attachment section now always visible in transaction form:
  - Section visible immediately when opening new or existing transaction
  - Clear helper message shown when transaction needs to be saved first
  - No confusion about file attachment availability
  - Better UX flow for attaching receipts and documents

#### Changed
- Transaction description field reduced from 3 rows to 1 row for more compact form
- Added resize-none to description textarea to prevent manual resizing
- File attachment UI improvements:
  - Always shows "Attachments" section in form
  - Displays helpful message "Save the transaction first to attach files" for new transactions
  - Upload functionality activates immediately after first save
  - Consistent UI across all transaction states

#### Impact
- Better mobile experience on large iPhones in PWA mode
- More compact and efficient transaction form
- Streamlined file attachment workflow with clear guidance
- Improved usability and discoverability of file attachment feature
- Reduced user confusion about when files can be attached

## [1.2.1] - 2025-12-07

### Localization & Icon Improvements

#### Fixed
- Account types now display correctly in Russian across all components:
  - Dashboard account cards now show localized type names
  - Accounts page displays translated type labels
  - All account types (card, cash, deposit, bank, savings, investment) properly localized
- Transfer transaction icon changed to bidirectional arrows (ArrowRightLeft)
  - Better represents money transfer between accounts
  - Maintains consistent blue gradient styling
  - Applied to both Dashboard and Transactions views

#### Impact
- Complete Russian localization for all account-related displays
- More intuitive visual representation of transfer operations
- Improved user experience for Russian-speaking users
- Better visual consistency across the application

## [1.2.0] - 2025-12-07

### Internationalization & UI Improvements

#### Added
- Complete internationalization (i18n) support with English and Russian languages
- Language switcher in the navigation bar with real-time switching
- Comprehensive translation system covering all UI elements:
  - Navigation menus
  - Forms and inputs
  - Buttons and actions
  - Messages and notifications
  - Dashboard statistics
  - Transaction management
  - Planning and budgets
  - AI Reports
- Language context for app-wide translation management
- Responsive header layout preventing text overflow

#### Changed
- Refactored all hardcoded text to use translation keys
- Improved header layout with proper text truncation
- Enhanced mobile responsiveness for navigation elements
- Updated button spacing and sizing for better mobile experience
- Email display now hidden on medium screens for better space management
- Language indicator text hidden on small screens (icon only)

#### Fixed
- Text overlap issue in navigation header on mobile devices
- Header elements now properly shrink on small screens
- Improved text truncation for long email addresses
- Better spacing between navigation elements

#### Impact
- Application fully accessible to Russian and English speakers
- Improved user experience on mobile devices
- Better text handling across different screen sizes
- Professional multilingual interface

## [1.1.0] - 2025-12-07

### Design Overhaul - Apple Liquid Glass Style

#### Added
- Complete UI redesign with glassmorphism (liquid glass) effect
- Blue and sky color palette throughout the application
- Backdrop blur effects on all major components
- Smooth animations and transitions
- Floating background gradients
- Gradient text effects on headings
- Enhanced button designs with hover effects and shadows
- Modern rounded corners and improved spacing
- Glass cards with frosted glass appearance
- Improved visual hierarchy with better contrast

#### Changed
- Replaced emerald theme with blue/sky gradient theme
- Updated all components to use glass effect styling
- Enhanced modal dialogs with backdrop blur
- Improved form inputs with glass styling
- Modernized navigation with glassmorphism
- Updated loading spinners to blue theme
- Enhanced card designs with glass hover effects
- Improved typography with gradient text
- Better visual feedback on interactive elements

#### Impact
- Premium, modern Apple-style interface
- Better visual appeal and user experience
- Smoother interactions with enhanced animations
- More cohesive design language across all pages
- Professional appearance suitable for production use

## [1.0.1] - 2025-12-07

### Security & Performance

#### Fixed
- Optimized RLS policies by wrapping `auth.uid()` with `(select auth.uid())` to prevent re-evaluation for each row
- Significantly improved query performance at scale for all authenticated operations
- Added missing indexes on foreign keys:
  - `planned_transactions.account_id`
  - `planned_transactions.category_id`
  - `planned_transactions.completed_transaction_id`
  - `transactions.to_account_id`
- Fixed function search path mutability warning
- Improved overall database query performance
- Reduced CPU usage for RLS policy evaluation

#### Impact
- Better scalability for large datasets
- Faster foreign key lookups
- More efficient authentication checks
- Production-ready security configuration

## [1.0.0] - 2025-12-07

### Added - Initial Release

#### Authentication & Security
- Email/password authentication via Supabase
- Row Level Security (RLS) on all database tables
- User data isolation and privacy
- Secure session management

#### Account Management
- Create, edit, and delete financial accounts
- Support for multiple account types:
  - Credit/Debit Cards
  - Bank Accounts
  - Deposits
  - Cash
- Real-time balance tracking
- Multi-currency support (RUB, USD, EUR, etc.)
- Custom color coding for accounts
- Account type icons

#### Transaction Management
- Record income and expense transactions
- Transfer money between accounts
- Categorize transactions
- Add descriptions and notes
- Date-based tracking
- Transaction filtering by type
- Transaction deletion with balance adjustment

#### Categories & Organization
- Hierarchical category system
- Parent categories and subcategories
- Separate income and expense categories
- Custom category colors
- Category management interface

#### Budgeting
- Set monthly budgets per category
- Visual budget progress bars
- Budget utilization tracking
- Budget warnings at 80% and 100% thresholds
- Historical budget data

#### Planned Transactions
- Schedule future income and expenses
- One-click execution of planned transactions
- Mark planned transactions as completed
- Automatic balance updates on execution
- Delete or modify planned transactions

#### AI-Powered Reports
- Natural language query interface
- Dynamic chart generation:
  - Bar charts for time-series data
  - Pie charts for categorical breakdowns
- Pre-built query templates
- Report summaries with totals and averages
- Interactive chart type switching
- Support for queries like:
  - "show expenses by category"
  - "monthly taxi expenses"
  - "income vs expenses"
  - Category-specific trends

#### User Interface
- Clean, modern design with Tailwind CSS
- Responsive layout (mobile, tablet, desktop)
- Mobile-first navigation
- Color-coded transaction types
- Real-time data updates
- Loading states and error handling
- Intuitive modal dialogs
- Toast notifications

#### Progressive Web App (PWA)
- Installable on mobile and desktop
- Offline functionality with Service Worker
- App manifest for native-like experience
- Cache-first strategy for assets
- Network-first for API calls
- iOS PWA support

#### Dashboard
- Total balance overview
- Monthly income summary
- Monthly expense summary
- Account cards with balances
- Recent transactions list
- Quick access to main features

#### Technical Implementation
- React 18 with TypeScript
- Vite build system
- Supabase backend integration
- PostgreSQL database
- Tailwind CSS styling
- Lucide React icons
- ESLint code quality
- Type-safe development

### Database Schema
- `accounts` table with RLS policies
- `categories` table with parent-child relationships
- `transactions` table with full CRUD operations
- `budgets` table with period tracking
- `planned_transactions` table with completion tracking
- `attachments` table for file metadata (structure ready)
- Comprehensive indexes for performance
- Foreign key constraints for data integrity

### Developer Experience
- TypeScript for type safety
- Component-based architecture
- Context API for state management
- Custom hooks for data fetching
- Reusable UI components
- Clean separation of concerns
- Documented code structure

## [Unreleased]

### Planned Features

#### High Priority
- File upload and attachment to transactions
- Receipt storage and viewing
- Export data to CSV/Excel
- Recurring transactions
- Transaction search and advanced filtering

#### Medium Priority
- Multi-currency exchange rate support
- Custom date range reports
- Report export as PDF/images
- Spending insights and recommendations
- Category spending limits
- Transaction tags

#### Low Priority
- Dark mode theme
- Multiple chart types (line, area, scatter)
- Email notifications
- Backup and restore functionality
- Transaction templates
- Shared accounts for families
- Mobile native apps

#### Future Considerations
- Bank account integration via APIs
- OCR for receipt scanning
- Financial goal tracking
- Investment portfolio tracking
- Tax report generation
- Machine learning for expense prediction
- Bill reminders
- Subscription tracking

## Version History

### [1.2.5] - 2025-12-07
- Added income tracking (Поступления) system
- Plan and track expected income by category
- Real-time income progress tracking with subcategory support
- New dedicated tab for income management

### [1.2.4] - 2025-12-07
- Added budget support for subcategories with automatic hierarchy tracking
- Added file attachment capability before transaction creation
- Enhanced budget calculation logic for category hierarchies
- Improved file attachment workflow with drag-and-drop interface

### [1.2.3] - 2025-12-07
- Fixed dynamic budget spending calculation with real-time updates
- Fixed modal forms overflow on mobile devices
- Improved data synchronization for budgets and transactions

### [1.2.2] - 2025-12-07
- Fixed transaction list layout for iPhone 14 Plus/Pro Max in PWA mode
- Reduced description field to 1 row for compact forms
- File attachments section always visible with clear guidance
- Improved file attachment discoverability and UX

### [1.2.1] - 2025-12-07
- Fixed Russian localization for account types
- Updated transfer transaction icon to bidirectional arrows
- Complete localization coverage for account displays

### [1.2.0] - 2025-12-07
- Full internationalization support (English/Russian)
- Improved responsive header layout
- Fixed text overflow issues on mobile devices

### [1.1.0] - 2025-12-07
- Apple-inspired liquid glass UI design
- Blue/sky gradient theme
- Enhanced animations and transitions

### [1.0.1] - 2025-12-07
- Database performance optimizations
- RLS policy improvements
- Added missing indexes

### [1.0.0] - 2025-12-07
- Initial release with core functionality
- Full-featured home accounting application
- AI-powered reporting
- PWA support

---

## Notes

### Breaking Changes
None (initial release)

### Migration Guide
Not applicable (initial release)

### Known Issues
- PWA icons need to be generated (placeholder in manifest)
- Service worker cache needs tuning for production
- Some edge cases in transfer operations may need refinement
- File upload size limits need to be documented

### Performance Notes
- Application loads in under 2 seconds on 3G
- Database queries optimized with indexes
- Lazy loading for large transaction lists recommended for future
- Charts render smoothly up to 50 data points

### Browser Support
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari 14+, Chrome Mobile 90+)

### Deployment
Tested and working on:
- Netlify
- Vercel
- GitHub Pages (with hash router)
- Self-hosted static servers

---

For detailed feature documentation, see [README.md](README.md)
