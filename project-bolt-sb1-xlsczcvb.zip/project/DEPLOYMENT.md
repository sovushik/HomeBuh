# Deployment Guide

This guide covers deploying Home Accounting to various platforms.

## Prerequisites

Before deploying, ensure you have:
- A Supabase project set up
- Database tables created (see README.md)
- Environment variables configured

## GitHub Setup

### 1. Create GitHub Repository

```bash
cd home-accounting

git init
git add .
git commit -m "Initial commit: Home Accounting v1.0.0"

git remote add origin https://github.com/yourusername/home-accounting.git
git branch -M main
git push -u origin main
```

### 2. Repository Configuration

Add the following to your repository:

**Description:**
```
Personal home accounting application with AI-powered reports. Built with React, TypeScript, and Supabase.
```

**Topics:**
```
finance, accounting, react, typescript, supabase, pwa, budgeting, expense-tracker, personal-finance
```

**Website:**
Your deployed URL (after deployment)

## Deployment Options

### Option 1: Netlify (Recommended)

#### Using Netlify CLI

1. Install Netlify CLI:
```bash
npm install -g netlify-cli
```

2. Build your app:
```bash
npm run build
```

3. Deploy:
```bash
netlify deploy
```

4. For production:
```bash
netlify deploy --prod
```

#### Using Netlify Dashboard

1. Go to [netlify.com](https://netlify.com)
2. Click "Add new site" > "Import an existing project"
3. Connect to GitHub and select your repository
4. Configure build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Add environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. Click "Deploy site"

### Option 2: Vercel

#### Using Vercel CLI

1. Install Vercel CLI:
```bash
npm install -g vercel
```

2. Deploy:
```bash
vercel
```

3. Follow the prompts

#### Using Vercel Dashboard

1. Go to [vercel.com](https://vercel.com)
2. Click "Add New" > "Project"
3. Import your GitHub repository
4. Configure:
   - Framework Preset: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Add environment variables
6. Click "Deploy"

### Option 3: GitHub Pages

1. Install gh-pages:
```bash
npm install --save-dev gh-pages
```

2. Add to package.json:
```json
{
  "homepage": "https://yourusername.github.io/home-accounting",
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

3. Update vite.config.ts:
```typescript
export default defineConfig({
  base: '/home-accounting/',
  // ... rest of config
})
```

4. Deploy:
```bash
npm run deploy
```

5. Enable GitHub Pages in repository settings

### Option 4: Self-Hosted

#### Using Docker

1. Create `Dockerfile`:
```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

2. Build and run:
```bash
docker build -t home-accounting .
docker run -p 8080:80 home-accounting
```

#### Using Static Server

1. Build the app:
```bash
npm run build
```

2. Serve with any static server:
```bash
npx serve dist
```

Or use nginx, Apache, or any web server.

## Environment Variables

### Development
Use `.env` file (not committed to git)

### Production
Set in your deployment platform:

**Netlify/Vercel:**
- Site Settings > Environment Variables

**GitHub Actions:**
- Repository Settings > Secrets

**Docker:**
- Use docker-compose or pass with `-e` flag

### Required Variables

```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJxxx...
```

## Database Setup

Before deploying, ensure Supabase is configured:

1. Create Supabase project at [supabase.com](https://supabase.com)
2. Run database migrations (from project README)
3. Verify RLS policies are active
4. Test with a dummy user

## Post-Deployment

### 1. Test the Application

- Sign up with test account
- Create test data
- Try all features
- Test on mobile devices
- Check PWA installation

### 2. Configure Domain (Optional)

**Netlify:**
- Domain Settings > Add custom domain

**Vercel:**
- Project Settings > Domains

**GitHub Pages:**
- Repository Settings > Pages > Custom domain

### 3. Enable HTTPS

Most platforms enable HTTPS automatically.
If self-hosting, use Let's Encrypt with Certbot.

### 4. Set Up Monitoring

Consider adding:
- Error tracking (Sentry)
- Analytics (Plausible, Google Analytics)
- Uptime monitoring (UptimeRobot)

## CI/CD Setup

### GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '18'

      - name: Install dependencies
        run: npm ci

      - name: Build
        run: npm run build
        env:
          VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}

      - name: Deploy to Netlify
        uses: netlify/actions/cli@master
        env:
          NETLIFY_AUTH_TOKEN: ${{ secrets.NETLIFY_AUTH_TOKEN }}
          NETLIFY_SITE_ID: ${{ secrets.NETLIFY_SITE_ID }}
        with:
          args: deploy --dir=dist --prod
```

## Troubleshooting

### Build Fails

- Check Node version (use 18+)
- Clear node_modules and reinstall
- Check for TypeScript errors
- Verify all dependencies are installed

### Environment Variables Not Working

- Ensure they start with `VITE_`
- Restart build after adding variables
- Check variable names match exactly

### PWA Not Installing

- Ensure HTTPS is enabled
- Check manifest.json is accessible
- Verify service worker is registered
- Clear browser cache

### Database Connection Issues

- Verify Supabase URL and key
- Check Supabase project is active
- Verify RLS policies don't block access
- Check browser console for errors

## Performance Optimization

### Build Optimization

1. Enable compression in vite.config.ts
2. Minimize bundle size
3. Use code splitting
4. Optimize images

### CDN Configuration

Configure caching headers:
```
/_headers
/*
  Cache-Control: public, max-age=31536000, immutable
/index.html
  Cache-Control: public, max-age=0, must-revalidate
```

### PWA Optimization

1. Generate proper icons (192x192, 512x512)
2. Configure service worker caching
3. Add offline page
4. Optimize cache strategy

## Backup and Recovery

### Database Backup

Supabase provides automatic backups.
For additional safety:
1. Export data regularly
2. Store backups securely
3. Test restoration process

### Code Backup

- Repository is backed up on GitHub
- Consider mirroring to GitLab/Bitbucket
- Tag releases: `git tag v1.0.0`

## Scaling Considerations

For high usage:
- Use Supabase Pro plan
- Implement rate limiting
- Add Redis caching
- Use CDN for static assets
- Monitor database performance

## Security Checklist

- [ ] HTTPS enabled
- [ ] Environment variables secured
- [ ] Supabase RLS policies active
- [ ] No secrets in code
- [ ] CSP headers configured
- [ ] Regular dependency updates
- [ ] Error messages don't leak info

## Support

After deployment:
- Add deployment URL to README
- Update CHANGELOG with release
- Create GitHub release
- Announce to users

---

Need help? Open an issue on GitHub!
