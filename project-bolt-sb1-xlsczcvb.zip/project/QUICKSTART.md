# Quick Start Guide

Get started with Home Accounting in 5 minutes!

## 1. Setup

### Install Dependencies

```bash
npm install
```

### Configure Environment

Create `.env` file:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these values from your [Supabase Dashboard](https://app.supabase.com):
1. Create a new project
2. Go to Settings > API
3. Copy the Project URL and anon public key

### Start Development Server

```bash
npm run dev
```

Open http://localhost:5173 in your browser.

## 2. First Time Use

### Create Account

1. Click "Sign Up"
2. Enter email and password
3. Click "Sign Up" button
4. Sign in with your credentials

### Add Your First Account

1. Navigate to "Accounts" tab
2. Click "New Account"
3. Fill in:
   - Name: "Main Card"
   - Type: "Card"
   - Initial Balance: 10000
   - Choose a color
4. Click "Create"

### Create Categories

1. Navigate to "Transactions" tab
2. Click "Categories" button
3. Add expense categories:
   - Groceries
   - Transportation
   - Entertainment
4. Add income categories:
   - Salary
   - Freelance

### Add Your First Transaction

1. Click "New Transaction"
2. Fill in:
   - Type: Expense
   - Amount: 500
   - Account: Main Card
   - Category: Groceries
   - Description: "Weekly groceries"
   - Date: Today
3. Click "Create"

Your account balance will update automatically!

## 3. Key Features

### Monthly Budget

1. Go to "Planned" tab
2. Switch to "Budgets"
3. Click "New Budget"
4. Select category (e.g., Groceries)
5. Set amount: 5000
6. Select current month
7. Click "Create"

Track your spending against the budget!

### Plan Future Transactions

1. Go to "Planned" tab
2. Click "New Planned Transaction"
3. Fill in details for upcoming expense
4. When it happens, click the checkmark to complete it

### Generate AI Reports

1. Go to "Reports" tab
2. Type a query:
   - "show expenses by category"
   - "monthly expenses"
   - "taxi spending"
3. Click "Generate"
4. View your dynamic charts!

Switch between bar charts and pie charts using the icons.

### Transfer Between Accounts

1. Create a second account first
2. Go to "Transactions"
3. Click "New Transaction"
4. Select type: "Transfer"
5. Choose from/to accounts
6. Enter amount
7. Click "Create"

Balances update on both accounts!

## 4. Tips

### Mobile Use

The app works great on mobile:
- Responsive design
- Touch-friendly buttons
- Swipe-friendly navigation

### PWA Installation

On mobile browsers:
1. Open the app
2. Use "Add to Home Screen"
3. Access like a native app!

### Data Security

- Your data is private and secure
- Only you can see your transactions
- Protected by Supabase Row Level Security

### Keyboard Shortcuts

- Enter key submits forms
- Escape key closes modals
- Tab key navigates form fields

## 5. Common Tasks

### View Dashboard

The Dashboard shows:
- Total balance across all accounts
- Monthly income
- Monthly expenses
- Recent transactions
- Account summaries

### Edit Account Balance

1. Go to "Accounts"
2. Click edit icon on account
3. Modify balance
4. Click "Update"

### Delete Transaction

1. Find transaction in list
2. Click trash icon
3. Confirm deletion
Balance automatically adjusts!

### Filter Transactions

Use the filter buttons:
- All
- Income
- Expense
- Transfer

### Export Data

Currently manual - copy from browser dev tools.
CSV export coming in next version!

## 6. Troubleshooting

### Can't Sign In?
- Check email/password
- Ensure Supabase project is active
- Check browser console for errors

### Balance Incorrect?
- Delete and re-add transaction
- Check for duplicate entries
- Verify transfer transactions

### Reports Not Working?
- Ensure you have transactions
- Try simpler queries first
- Check date ranges

### App Not Loading?
- Clear browser cache
- Check internet connection
- Verify .env configuration

## 7. Next Steps

- Set up all your accounts
- Add categories for your spending habits
- Import past transactions manually
- Set monthly budgets
- Review reports weekly
- Plan recurring expenses

## 8. Getting Help

- Read full [README.md](README.md)
- Check [CHANGELOG.md](CHANGELOG.md) for updates
- Open GitHub issue for bugs
- Review [CONTRIBUTING.md](CONTRIBUTING.md) to contribute

## 9. Development

### Build for Production

```bash
npm run build
```

Output in `dist/` folder.

### Deploy

Works on:
- Netlify (drag & drop dist folder)
- Vercel (connect GitHub repo)
- GitHub Pages
- Any static host

### Environment Variables

For production, set:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## 10. Sample Data

Want to test with sample data? Add:

**Accounts:**
- Credit Card (balance: 15000)
- Savings (balance: 50000)
- Cash (balance: 5000)

**Categories:**
- Food & Dining (expense)
- Transportation (expense)
- Salary (income)
- Gifts (income)

**Transactions:**
- Various amounts in different categories
- Mix of dates over past month
- Include some transfers

Then generate reports to see visualizations!

---

Enjoy using Home Accounting! 💰
