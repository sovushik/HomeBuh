/*
  # Create income budgets table

  1. New Tables
    - `income_budgets`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid) - References auth.users
      - `category_id` (uuid) - References categories table (income categories)
      - `amount` (numeric) - Expected income amount
      - `period_start` (date) - Start of tracking period
      - `period_end` (date) - End of tracking period
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `income_budgets` table
    - Add policy for users to read their own income budgets
    - Add policy for users to create their own income budgets
    - Add policy for users to update their own income budgets
    - Add policy for users to delete their own income budgets

  3. Indexes
    - Index on user_id for faster queries
    - Index on category_id for budget calculations
    - Index on period_start and period_end for date filtering

  This table tracks expected income (поступления) similar to expense budgets,
  allowing users to plan and track their expected income by category and period.
*/

CREATE TABLE IF NOT EXISTS income_budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  amount numeric NOT NULL CHECK (amount >= 0),
  period_start date NOT NULL,
  period_end date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_period CHECK (period_end >= period_start)
);

-- Enable RLS
ALTER TABLE income_budgets ENABLE ROW LEVEL SECURITY;

-- Users can view their own income budgets
CREATE POLICY "Users can view own income budgets"
  ON income_budgets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Users can create their own income budgets
CREATE POLICY "Users can create own income budgets"
  ON income_budgets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own income budgets
CREATE POLICY "Users can update own income budgets"
  ON income_budgets
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Users can delete their own income budgets
CREATE POLICY "Users can delete own income budgets"
  ON income_budgets
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_income_budgets_user_id ON income_budgets(user_id);
CREATE INDEX IF NOT EXISTS idx_income_budgets_category_id ON income_budgets(category_id);
CREATE INDEX IF NOT EXISTS idx_income_budgets_period ON income_budgets(period_start, period_end);

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_income_budgets_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER income_budgets_updated_at
  BEFORE UPDATE ON income_budgets
  FOR EACH ROW
  EXECUTE FUNCTION update_income_budgets_updated_at();