/*
  # Security and Performance Optimization

  ## Overview
  Fix security issues and performance bottlenecks identified by Supabase linter.

  ## Changes

  ### 1. Missing Indexes for Foreign Keys
  Add indexes for unindexed foreign keys to improve query performance:
  - `planned_transactions.account_id`
  - `planned_transactions.category_id`
  - `planned_transactions.completed_transaction_id`
  - `transactions.to_account_id`

  ### 2. Optimize RLS Policies
  Wrap `auth.uid()` calls with `(select auth.uid())` to prevent re-evaluation
  for each row, significantly improving query performance at scale.
  
  This affects all RLS policies on:
  - accounts
  - categories
  - transactions
  - budgets
  - planned_transactions
  - attachments

  ### 3. Function Search Path
  Fix search path mutability warning for trigger function

  ## Performance Impact
  - Faster foreign key lookups
  - Reduced CPU usage for RLS policy evaluation
  - Better scalability for large datasets
*/

-- Add missing indexes for foreign keys
CREATE INDEX IF NOT EXISTS idx_planned_transactions_account_id 
  ON planned_transactions(account_id);

CREATE INDEX IF NOT EXISTS idx_planned_transactions_category_id 
  ON planned_transactions(category_id);

CREATE INDEX IF NOT EXISTS idx_planned_transactions_completed_transaction_id 
  ON planned_transactions(completed_transaction_id);

CREATE INDEX IF NOT EXISTS idx_transactions_to_account_id 
  ON transactions(to_account_id);

-- Drop and recreate RLS policies with optimized auth checks

-- Accounts policies
DROP POLICY IF EXISTS "Users can view own accounts" ON accounts;
DROP POLICY IF EXISTS "Users can insert own accounts" ON accounts;
DROP POLICY IF EXISTS "Users can update own accounts" ON accounts;
DROP POLICY IF EXISTS "Users can delete own accounts" ON accounts;

CREATE POLICY "Users can view own accounts"
  ON accounts FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own accounts"
  ON accounts FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own accounts"
  ON accounts FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own accounts"
  ON accounts FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Categories policies
DROP POLICY IF EXISTS "Users can view own categories" ON categories;
DROP POLICY IF EXISTS "Users can insert own categories" ON categories;
DROP POLICY IF EXISTS "Users can update own categories" ON categories;
DROP POLICY IF EXISTS "Users can delete own categories" ON categories;

CREATE POLICY "Users can view own categories"
  ON categories FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own categories"
  ON categories FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own categories"
  ON categories FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own categories"
  ON categories FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Transactions policies
DROP POLICY IF EXISTS "Users can view own transactions" ON transactions;
DROP POLICY IF EXISTS "Users can insert own transactions" ON transactions;
DROP POLICY IF EXISTS "Users can update own transactions" ON transactions;
DROP POLICY IF EXISTS "Users can delete own transactions" ON transactions;

CREATE POLICY "Users can view own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own transactions"
  ON transactions FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own transactions"
  ON transactions FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Budgets policies
DROP POLICY IF EXISTS "Users can view own budgets" ON budgets;
DROP POLICY IF EXISTS "Users can insert own budgets" ON budgets;
DROP POLICY IF EXISTS "Users can update own budgets" ON budgets;
DROP POLICY IF EXISTS "Users can delete own budgets" ON budgets;

CREATE POLICY "Users can view own budgets"
  ON budgets FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own budgets"
  ON budgets FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own budgets"
  ON budgets FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own budgets"
  ON budgets FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Planned transactions policies
DROP POLICY IF EXISTS "Users can view own planned transactions" ON planned_transactions;
DROP POLICY IF EXISTS "Users can insert own planned transactions" ON planned_transactions;
DROP POLICY IF EXISTS "Users can update own planned transactions" ON planned_transactions;
DROP POLICY IF EXISTS "Users can delete own planned transactions" ON planned_transactions;

CREATE POLICY "Users can view own planned transactions"
  ON planned_transactions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own planned transactions"
  ON planned_transactions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own planned transactions"
  ON planned_transactions FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own planned transactions"
  ON planned_transactions FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Attachments policies
DROP POLICY IF EXISTS "Users can view own attachments" ON attachments;
DROP POLICY IF EXISTS "Users can insert own attachments" ON attachments;
DROP POLICY IF EXISTS "Users can delete own attachments" ON attachments;

CREATE POLICY "Users can view own attachments"
  ON attachments FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own attachments"
  ON attachments FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own attachments"
  ON attachments FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Fix function search path if the function exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column'
  ) THEN
    ALTER FUNCTION update_updated_at_column() SET search_path = public, pg_temp;
  END IF;
END $$;