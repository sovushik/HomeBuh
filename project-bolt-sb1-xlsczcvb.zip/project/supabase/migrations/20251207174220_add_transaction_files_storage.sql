/*
  # Add Transaction Files Storage

  1. Storage
    - Create `transaction-files` bucket for storing transaction attachments
    - Configure RLS policies for secure file access
  
  2. New Tables
    - `transaction_files`
      - `id` (uuid, primary key)
      - `transaction_id` (uuid, foreign key to transactions)
      - `file_name` (text, original file name)
      - `file_path` (text, storage path)
      - `file_size` (bigint, size in bytes)
      - `file_type` (text, MIME type)
      - `uploaded_by` (uuid, foreign key to auth.users)
      - `created_at` (timestamptz)

  3. Security
    - Enable RLS on `transaction_files` table
    - Add policies for authenticated users to manage their files
    - Storage policies to allow authenticated users to upload/download their files
*/

-- Create transaction_files table
CREATE TABLE IF NOT EXISTS transaction_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid REFERENCES transactions(id) ON DELETE CASCADE NOT NULL,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_size bigint NOT NULL,
  file_type text NOT NULL,
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE transaction_files ENABLE ROW LEVEL SECURITY;

-- Policies for transaction_files
CREATE POLICY "Users can view files for their transactions"
  ON transaction_files FOR SELECT
  TO authenticated
  USING (
    uploaded_by = auth.uid()
  );

CREATE POLICY "Users can upload files to their transactions"
  ON transaction_files FOR INSERT
  TO authenticated
  WITH CHECK (
    uploaded_by = auth.uid() AND
    EXISTS (
      SELECT 1 FROM transactions
      WHERE transactions.id = transaction_files.transaction_id
      AND transactions.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete their transaction files"
  ON transaction_files FOR DELETE
  TO authenticated
  USING (
    uploaded_by = auth.uid()
  );

-- Create storage bucket for transaction files
INSERT INTO storage.buckets (id, name, public)
VALUES ('transaction-files', 'transaction-files', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for transaction-files bucket
CREATE POLICY "Users can upload their transaction files"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'transaction-files' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can view their transaction files"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'transaction-files' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete their transaction files"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'transaction-files' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_transaction_files_transaction_id 
  ON transaction_files(transaction_id);
